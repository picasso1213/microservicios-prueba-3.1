package com.example.devolucion.service;

import com.example.devolucion.model.Devolucion;
import com.example.devolucion.repository.DevolucionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class DevolucionServiceTest {

    @Mock
    private DevolucionRepository repository;

    @InjectMocks
    private DevolucionService service;

    @Test
    void deberiaRetornarDevolucionCuandoExiste() {

        Devolucion devolucion = new Devolucion();
        devolucion.setId(1L);
        devolucion.setIdPrestamo(7L);
        devolucion.setFechaDevolucion(LocalDate.of(2026, 6, 21));
        devolucion.setEstadoLibro("Bueno");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(devolucion));

        Optional<Devolucion> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Bueno", resultado.get().getEstadoLibro());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarDevolucion() {

        Devolucion devolucion = new Devolucion();
        devolucion.setIdPrestamo(7L);
        devolucion.setFechaDevolucion(LocalDate.of(2026, 6, 21));
        devolucion.setEstadoLibro("Dañado");

        Mockito.when(repository.save(devolucion))
                .thenReturn(devolucion);

        Devolucion guardada = service.guardarDevolucion(devolucion);

        assertEquals("Dañado", guardada.getEstadoLibro());

        verify(repository).save(devolucion);
    }
}
