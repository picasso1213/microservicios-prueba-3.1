package com.example.devolucion.controller;

import com.example.devolucion.client.PrestamoClient;
import com.example.devolucion.model.Devolucion;
import com.example.devolucion.model.Prestamo;
import com.example.devolucion.service.DevolucionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DevolucionController.class)
@AutoConfigureMockMvc(addFilters = false)
class DevolucionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private DevolucionService service;

    @MockitoBean
    private PrestamoClient prestamoClient;

    @Test
    void deberiaRetornarDevolucionPorId() throws Exception {

        Devolucion devolucion = new Devolucion();
        devolucion.setId(1L);
        devolucion.setIdPrestamo(7L);
        devolucion.setFechaDevolucion(LocalDate.of(2026, 6, 21));
        devolucion.setEstadoLibro("Bueno");

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(devolucion));

        mockMvc.perform(get("/api/v1/devoluciones/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.estadoLibro").value("Bueno"));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearDevolucion() throws Exception {

        Prestamo prestamo = new Prestamo();
        prestamo.setIdPrestamo(7L);

        Devolucion devolucion = new Devolucion();
        devolucion.setId(1L);
        devolucion.setIdPrestamo(7L);
        devolucion.setFechaDevolucion(LocalDate.of(2026, 6, 21));
        devolucion.setEstadoLibro("Bueno");

        when(prestamoClient.obtenerPrestamo(7L))
                .thenReturn(Mono.just(prestamo));

        when(service.guardarDevolucion(any(Devolucion.class)))
                .thenReturn(devolucion);

        String json = """
                {
                    "idPrestamo": 7,
                    "fechaDevolucion": "2026-06-21",
                    "estadoLibro": "Bueno"
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/devoluciones")
                        .contentType("application/json")
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idPrestamo").value(7))
                .andExpect(jsonPath("$.estadoLibro").value("Bueno"));

        verify(prestamoClient).obtenerPrestamo(7L);
        verify(service).guardarDevolucion(any(Devolucion.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "estadoLibro": "Bueno"
                }
                """;

        mockMvc.perform(post("/api/v1/devoluciones")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarDevoluciones() throws Exception {

        Devolucion d1 = new Devolucion();
        d1.setId(1L);
        d1.setIdPrestamo(7L);
        d1.setEstadoLibro("Bueno");

        when(service.listar())
                .thenReturn(List.of(d1));

        mockMvc.perform(get("/api/v1/devoluciones"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));

        verify(service).listar();
    }

    @Test
    void deberiaBuscarPorFecha() throws Exception {

        Devolucion d1 = new Devolucion();
        d1.setId(1L);
        d1.setFechaDevolucion(LocalDate.of(2026, 6, 21));

        when(service.buscarPorFecha(LocalDate.of(2026, 6, 21)))
                .thenReturn(List.of(d1));

        mockMvc.perform(get("/api/v1/devoluciones/fechaDevolucion/2026-06-21"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));

        verify(service).buscarPorFecha(LocalDate.of(2026, 6, 21));
    }

    @Test
    void deberiaBorrarDevolucion() throws Exception {

        mockMvc.perform(delete("/api/v1/devoluciones/id/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarPorId(1L);
    }
}
