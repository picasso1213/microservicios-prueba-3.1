CREATE TABLE devolucion (
                            id BIGINT PRIMARY KEY AUTO_INCREMENT,
                            id_prestamo   BIGINT,
                            fecha_devolucion DATE,
                            estado_libro     VARCHAR(50)
);