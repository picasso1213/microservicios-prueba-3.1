package com.example.devolucion.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.devolucion.client.PrestamoClient;
import com.example.devolucion.model.Devolucion;
import com.example.devolucion.model.Prestamo;
import com.example.devolucion.service.DevolucionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/devoluciones")
@RequiredArgsConstructor
public class DevolucionController {

    private final PrestamoClient prestamoClient;
    @Autowired
    private final DevolucionService service;

    @Operation(
            summary = "Crear devolucion",
            description = "Registra una nueva devolucion en el sistema"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Devolucion registrada correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public Mono<ResponseEntity<Devolucion>> guardarDevolucion(@Valid @RequestBody Devolucion devolucion) {
        return prestamoClient.obtenerPrestamo(devolucion.getIdPrestamo())
                .map(prestamo -> {
                    Devolucion guardada = service.guardarDevolucion(devolucion);
                    guardada.add(linkTo(methodOn(DevolucionController.class).listar()).withRel("mostrar todas las devoluciones"));
                    guardada.add(linkTo(methodOn(DevolucionController.class).buscarPorId(guardada.getId())).withSelfRel());
                    guardada.add(linkTo(methodOn(DevolucionController.class).borrarPorId(guardada.getId())).withRel("borrar devolucion"));
                    guardada.add(linkTo(methodOn(DevolucionController.class).actualizarDevolucion(guardada)).withRel("actulizar devolucion"));
                    return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
                });
    }

    @Operation(
            summary = "Listar devoluciones",
            description = "Muestra una lista con todas las devoluciones registradas en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Devoluciones obtenidas correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Devolucion> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca una devolucion dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Devolucion encontrada correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Devolucion no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Devolucion> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(devolucion -> {
                    devolucion.add(linkTo(methodOn(DevolucionController.class).listar()).withRel("mostrar todas las devoluciones"));
                    devolucion.add(linkTo(methodOn(DevolucionController.class).borrarPorId(devolucion.getId())).withRel("borrar devoluciones"));
                    devolucion.add(linkTo(methodOn(DevolucionController.class).actualizarDevolucion(devolucion)).withRel("actulizar devoluciones"));
                    return ResponseEntity.ok(devolucion);
                })
                .orElse(ResponseEntity.notFound().build());
    }


    @Operation(
            summary = "Buscar por fecha",
            description = "Muestra una lista de devoluciones registradas en el dia buscado."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Devoluciones encontradas correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron devoluciones en la fecha indicada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/fechaDevolucion/{fechaDevolucion}")
    public ResponseEntity<List<Devolucion>> buscarPorFechaDevolucion(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)LocalDate fechaDevolucion) {
        List<Devolucion> devoluciones = service.buscarPorFecha(fechaDevolucion);
        if(devoluciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            devoluciones.forEach(devolucion -> {
                devolucion.add(linkTo(methodOn(DevolucionController.class).listar()).withRel("mostrar todas las devoluciones"));
                devolucion.add(linkTo(methodOn(DevolucionController.class).borrarPorId(devolucion.getId())).withRel("borrar devoluciones"));
                devolucion.add(linkTo(methodOn(DevolucionController.class).actualizarDevolucion(devolucion)).withRel("actulizar devoluciones"));
            });
            return ResponseEntity.ok(devoluciones);
        }
    }

    @Operation(
            summary = "Actualizar devolucion",
            description = "Actualiza los datos de una devolucion."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Devolucion actualizada correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Devolucion no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Devolucion> actualizarDevolucion(@RequestBody Devolucion devolucion) {
        Devolucion deActualizada = service.actualizarDevolucion(devolucion);
        deActualizada.add(linkTo(methodOn(DevolucionController.class).listar()).withRel("mostrar todas las devoluciones"));
        deActualizada.add(linkTo(methodOn(DevolucionController.class).borrarPorId(deActualizada.getId())).withRel("borrar devoluciones"));
        deActualizada.add(linkTo(methodOn(DevolucionController.class).actualizarDevolucion(deActualizada)).withRel("actulizar devoluciones"));
        return ResponseEntity.ok(deActualizada);
    }

    @Operation(
            summary = "Borrar devolucion",
            description = "Se borra una devolucion del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Devolucion eliminada correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Devolucion no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try{
            service.borrarPorId(id);
        }catch(NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }

}