package com.example.devolucion.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa una devolucion registrada en el sistema")
public class Devolucion extends RepresentationModel<Devolucion> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico de la devolucion",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @NotNull
    @Schema(
            description = "Identificador unico del prestamo asociado a la devolucion",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idPrestamo;
    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Schema(
            description = "Fecha en la que se efectuo la devolucion el libro prestado",
            example = "2026-09-12",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private LocalDate fechaDevolucion;
    @NotBlank
    @Schema(
            description = "Estado de conservacion en el que se encuentra el libro al momento de su devolucion",
            example = "dañado",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estadoLibro;
}