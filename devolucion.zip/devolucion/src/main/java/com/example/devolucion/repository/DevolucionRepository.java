package com.example.devolucion.repository;

import com.example.devolucion.model.Devolucion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface DevolucionRepository extends JpaRepository<Devolucion, Long> {
    List<Devolucion> findByFechaDevolucion(LocalDate fechaDevolucion);
}
