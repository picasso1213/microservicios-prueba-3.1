package com.example.devolucion.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidExceptionErrors(MethodArgumentNotValidException ex){

        HashMap<String, String> errores = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(fieldError -> {
            errores.put(fieldError.getField(), fieldError.getDefaultMessage());
        });

        return new ErrorResponse(
                400,
                "Error de validación",
                errores
        );
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ErrorResponse> handleResponseStatusException(ResponseStatusException ex) {
        ErrorResponse er = new ErrorResponse(
                ex.getStatusCode().value(),
                ex.getReason(),
                null
        );
        return ResponseEntity.status(ex.getStatusCode()).body(er);
    }
}
