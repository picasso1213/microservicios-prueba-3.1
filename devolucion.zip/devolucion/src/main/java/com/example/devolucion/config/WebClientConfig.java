package com.example.devolucion.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Value("${prestamo.service.url:http://localhost:9095}")
    private String prestamoServiceUrl;

    @Bean
    public WebClient prestamoWebClient() {
        return WebClient.builder()
                .baseUrl(prestamoServiceUrl)
                .build();
    }
}