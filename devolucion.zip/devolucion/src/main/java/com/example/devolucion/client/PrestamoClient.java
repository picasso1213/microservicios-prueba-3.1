package com.example.devolucion.client;

import com.example.devolucion.model.Prestamo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class PrestamoClient {

    private final WebClient prestamoWebClient;

    public Mono<Prestamo> obtenerPrestamo(Long id) {
        return prestamoWebClient.get()
                .uri("/api/v1/prestamos/id/" + id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "prestamo no encontrado"
                        ))
                )
                .bodyToMono(Prestamo.class);
    }
}
