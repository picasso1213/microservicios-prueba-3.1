package com.example.devolucion.service;

import com.example.devolucion.model.Devolucion;
import com.example.devolucion.repository.DevolucionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class DevolucionService {

    @Autowired
    private DevolucionRepository repository;

    public List<Devolucion> listar() {
        return repository.findAll();
    }

    public Optional<Devolucion> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarPorId(Long id) {
        repository.deleteById(id);
    }

    public Devolucion guardarDevolucion(Devolucion devolucion) {
        return repository.save(devolucion);
    }

    public Devolucion actualizarDevolucion(Devolucion devolucion) {
        return repository.save(devolucion);
    }

    public List<Devolucion> buscarPorFecha(LocalDate fecha){
        return repository.findByFechaDevolucion(fecha);
    }
}