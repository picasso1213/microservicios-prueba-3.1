package com.example.devolucion.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Entidad que representa los datos del prestamo asociado a la devolucion")
public class Prestamo {
    @Schema(
            description = "Identificador unico del prestamo",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long idPrestamo;
    @Schema(
            description = "Identiicador unico del libro que se esta prestando",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idLibro;
    @Schema(
            description = "Identiicador unico del usuario que pide el prestamo",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idUsuario;
    @Schema(
            description = "Fecha en la que se inicia el prestamo",
            example = "2026-07-23",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String fechaInicioPrestamo;
    @Schema(
            description = "Fecha en la que se termina el prestamo",
            example = "2026-08-23",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String fechaTerminoPrestamo;
    @Schema(
            description = "Estado en el que se encuentra el prestamo",
            example = "activo",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estadoPrestamo;
}