CREATE TABLE pago(
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_multa BIGINT,
    id_usuario BIGINT,
    fecha_pago DATE,
    estado_pago VARCHAR(50),
    metodo_pago VARCHAR(50)
)