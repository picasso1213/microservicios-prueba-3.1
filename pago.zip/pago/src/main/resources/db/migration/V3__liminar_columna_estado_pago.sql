ALTER TABLE pago
    DROP COLUMN estado_pago;