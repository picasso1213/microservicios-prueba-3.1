ALTER TABLE pago
    ADD COLUMN monto_pago INT;