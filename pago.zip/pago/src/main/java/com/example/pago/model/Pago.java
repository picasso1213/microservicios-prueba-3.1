package com.example.pago.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

import javax.swing.*;
import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un pagoregistrado en el sistema")
public class Pago extends RepresentationModel<Pago> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico del pago",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @NotNull
    @Schema(
            description = "Identificador unico de la multa asociada al pago",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idMulta;
    @NotNull
    @Schema(
            description = "Identificador unico del usuario asociada al pago",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idUsuario;
    @Schema(
            description = "Monto a pagar",
            example = "15000"
    )
    private Integer montoPago;
    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Schema(
            description = "Fecha en la que se realiza el pago de la multa",
            example = "2026-06-13",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private LocalDate fechaPago;
    @NotBlank
    @Schema(
            description = "Metodo de pago utilizado para cancelar la multa",
            example = "Efectivo",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String metodoPago;

}
