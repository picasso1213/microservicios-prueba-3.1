package com.example.pago.client;

import com.example.pago.model.Multa;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class MultaClient {

    private final WebClient webClient;

    public Mono<Multa> obtenerMulta(Long id){
        return webClient.get()
                .uri("/api/v1/multas/id/" + id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Multa no encotrada"
                        ))
                )
                .bodyToMono(Multa.class);
    }


}
