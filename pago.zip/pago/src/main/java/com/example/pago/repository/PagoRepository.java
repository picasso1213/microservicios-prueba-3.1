package com.example.pago.repository;

import com.example.pago.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface PagoRepository extends JpaRepository<Pago, Long> {
    List<Pago> findByFechaPago(LocalDate fechaPago);

    List<Pago> findByMetodoPago(String metodoPago);
}
