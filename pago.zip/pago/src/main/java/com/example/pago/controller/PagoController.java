package com.example.pago.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.pago.model.Pago;
import com.example.pago.service.PagoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/pagos")
@RequiredArgsConstructor
public class PagoController {

    @Autowired
    private final PagoService service;

    @Operation(
            summary = "Crear pago",
            description = "Registra un nuevo pago en el sistema"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Pago registrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public Mono<ResponseEntity<Pago>> guardarPago(@Valid @RequestBody Pago pago) {
        return service.obtenerDatosMulta(pago)
                .map(datosPago -> {
                    Pago guardado = service.guardarPago(datosPago);
                    guardado.add(linkTo(methodOn(PagoController.class).listar()).withRel("mostrar todos los pagos"));
                    guardado.add(linkTo(methodOn(PagoController.class).buscarPorId(guardado.getId())).withSelfRel());
                    guardado.add(linkTo(methodOn(PagoController.class).borrarPorId(guardado.getId())).withRel("borrar pago"));
                    guardado.add(linkTo(methodOn(PagoController.class).actualizarPago(guardado)).withRel("actualizar pago"));
                    return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
                });
    }

    @Operation(
            summary = "Listar pagos",
            description = "Muestra una lista con todos los pagos registrados en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Pagos obtenidos correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Pago> listar(){
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca un prestamo dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Prestamo encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Prestamo no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Pago> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(pago -> {
                    pago.add(linkTo(methodOn(PagoController.class).listar()).withRel("mostrar todos los pagos"));
                    pago.add(linkTo(methodOn(PagoController.class).buscarPorId(pago.getId())).withSelfRel());
                    pago.add(linkTo(methodOn(PagoController.class).borrarPorId(pago.getId())).withRel("borrar pago"));
                    pago.add(linkTo(methodOn(PagoController.class).actualizarPago(pago)).withRel("actualizar pago"));
                    return ResponseEntity.ok(pago);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por fecha pago",
            description = "Muestra una lista de pagos realizados en la fecha buscada."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Pagos encontrados correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron pagos efectados en la fecha indicada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/fechaPago/{fechaPago}")
    public ResponseEntity<List<Pago>> buscarPorFecha(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaPago){
        List<Pago> pagos = service.buscarPorFecha(fechaPago);
        if(pagos.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            pagos.forEach(pago -> {
                pago.add(linkTo(methodOn(PagoController.class).listar()).withRel("mostrar todos los pagos"));
                pago.add(linkTo(methodOn(PagoController.class).borrarPorId(pago.getId())).withRel("borrar pago"));
                pago.add(linkTo(methodOn(PagoController.class).actualizarPago(pago)).withRel("actualizar pago"));
            });
            return ResponseEntity.ok(pagos);
        }
    }

    @Operation(
            summary = "Buscar por metodo pago",
            description = "Muestra una lista de pagos cuyo metodo de pago coincida con el buscado"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Pagos encontrados correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron pagos realizados con el metodo de pago realizado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/metodoPago/{metodoPago}")
    public ResponseEntity<List<Pago>> buscarPorMetodoPago(@PathVariable String metodoPago){
        List<Pago> pagos = service.buscarPorMetodoPago(metodoPago);
        if(pagos.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            pagos.forEach(pago -> {
                pago.add(linkTo(methodOn(PagoController.class).listar()).withRel("mostrar todos los pagos"));
                pago.add(linkTo(methodOn(PagoController.class).borrarPorId(pago.getId())).withRel("borrar pago"));
                pago.add(linkTo(methodOn(PagoController.class).actualizarPago(pago)).withRel("actualizar pago"));
            });
            return ResponseEntity.ok(pagos);
        }
    }

    @Operation(
            summary = "Actualizar pago",
            description = "Actualiza los datos de un pago."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Pago actualizado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Pago no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Pago> actualizarPago(@RequestBody Pago pago) {
        Pago paActualizado = service.actualizarPago(pago);
        paActualizado.add(linkTo(methodOn(PagoController.class).listar()).withRel("mostrar todos los pagos"));
        paActualizado.add(linkTo(methodOn(PagoController.class).borrarPorId(paActualizado.getId())).withRel("borrar pago"));
        paActualizado.add(linkTo(methodOn(PagoController.class).actualizarPago(paActualizado)).withRel("actualizar pago"));
        return ResponseEntity.ok(paActualizado);
    }

    @Operation(
            summary = "Borrar pago",
            description = "Se borra un pago del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Pago eliminado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Pago no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try{
            service.borrarPorId(id);
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }


}
