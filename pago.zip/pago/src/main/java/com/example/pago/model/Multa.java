package com.example.pago.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Entidad que representa los datos de una multa registrada en el sistema")
public class Multa {

    @Schema(
            description = "Identificador unico de la multa",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @Schema(
            description = "Identificador unico del usuario asociado a la multa",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idUsuario;
    @Schema(
            description = "Identificador unico del retraso asociado a la multa",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idRetraso;
    @Schema(
            description = "Monto a pagar, basado en los dias de retraso",
            example = "15000",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Integer calculoMulta;
    @Schema(
            description = "Estado en el que se encuentra la multa",
            example = "Pagada",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estadoMulta;

}
