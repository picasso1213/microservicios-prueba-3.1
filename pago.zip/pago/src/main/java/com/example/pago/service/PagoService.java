package com.example.pago.service;

import com.example.pago.client.MultaClient;
import com.example.pago.model.Pago;
import com.example.pago.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PagoService {

    @Autowired
    private PagoRepository repository;
    private final MultaClient multaClient;


    public Mono<Pago> obtenerDatosMulta(Pago pago) {
        return multaClient.obtenerMulta(pago.getIdMulta())
                .map(multa -> {
                    pago.setIdUsuario(multa.getIdUsuario());
                    pago.setMontoPago(multa.getCalculoMulta());
                    return pago;
                });
    }

    public List<Pago> listar() {
        return repository.findAll();
    }

    public Optional<Pago> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarPorId(Long id){
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Pago guardarPago(Pago pago) {
        return repository.save(pago);
    }

    public Pago actualizarPago(Pago pago) {
        return repository.save(pago);
    }

    public List<Pago> buscarPorFecha(LocalDate fecha){
        return repository.findByFechaPago(fecha);
    }

    public List<Pago> buscarPorMetodoPago(String metodoPago) {
        return repository.findByMetodoPago(metodoPago);
    }

}
