package com.example.pago.service;

import com.example.pago.client.MultaClient;
import com.example.pago.model.Pago;
import com.example.pago.repository.PagoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class PagoServiceTest {

    @Mock
    private PagoRepository repository;

    @Mock
    private MultaClient multaClient;

    private PagoService service;

    @BeforeEach
    void setUp() {
        service = new PagoService(multaClient);
        ReflectionTestUtils.setField(service, "repository", repository);
    }

    @Test
    void deberiaRetornarPagoCuandoExiste() {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setIdMulta(2L);
        pago.setIdUsuario(5L);
        pago.setMontoPago(15000);
        pago.setFechaPago(LocalDate.of(2026, 6, 21));
        pago.setMetodoPago("Efectivo");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(pago));

        Optional<Pago> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Efectivo", resultado.get().getMetodoPago());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarPago() {

        Pago pago = new Pago();
        pago.setIdMulta(2L);
        pago.setIdUsuario(5L);
        pago.setMontoPago(15000);
        pago.setFechaPago(LocalDate.of(2026, 6, 21));
        pago.setMetodoPago("Transferencia");

        Mockito.when(repository.save(pago))
                .thenReturn(pago);

        Pago guardado = service.guardarPago(pago);

        assertEquals("Transferencia", guardado.getMetodoPago());

        verify(repository).save(pago);
    }
}