package com.example.pago.controller;

import com.example.pago.model.Pago;
import com.example.pago.service.PagoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PagoController.class)
@AutoConfigureMockMvc(addFilters = false)
class PagoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private PagoService service;

    @Test
    void deberiaRetornarPagoPorId() throws Exception {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setIdMulta(2L);
        pago.setIdUsuario(5L);
        pago.setMontoPago(15000);
        pago.setFechaPago(LocalDate.of(2026, 6, 21));
        pago.setMetodoPago("Efectivo");

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(pago));

        mockMvc.perform(get("/api/v1/pagos/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.metodoPago").value("Efectivo"));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearPago() throws Exception {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setIdMulta(2L);
        pago.setIdUsuario(5L);
        pago.setMontoPago(15000);
        pago.setFechaPago(LocalDate.of(2026, 6, 21));
        pago.setMetodoPago("Efectivo");

        when(service.obtenerDatosMulta(any(Pago.class)))
                .thenReturn(Mono.just(pago));

        when(service.guardarPago(any(Pago.class)))
                .thenReturn(pago);

        String json = """
                {
                    "idMulta": 2,
                    "idUsuario": 5,
                    "fechaPago": "2026-06-21",
                    "metodoPago": "Efectivo"
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/pagos")
                        .contentType("application/json")
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.metodoPago").value("Efectivo"))
                .andExpect(jsonPath("$.montoPago").value(15000));

        verify(service).obtenerDatosMulta(any(Pago.class));
        verify(service).guardarPago(any(Pago.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "metodoPago": "Efectivo"
                }
                """;

        mockMvc.perform(post("/api/v1/pagos")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarPagos() throws Exception {

        Pago p1 = new Pago();
        p1.setId(1L);
        p1.setMetodoPago("Efectivo");

        when(service.listar())
                .thenReturn(List.of(p1));

        mockMvc.perform(get("/api/v1/pagos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));

        verify(service).listar();
    }

    @Test
    void deberiaBuscarPorFecha() throws Exception {

        Pago p1 = new Pago();
        p1.setId(1L);
        p1.setFechaPago(LocalDate.of(2026, 6, 21));

        when(service.buscarPorFecha(LocalDate.of(2026, 6, 21)))
                .thenReturn(List.of(p1));

        mockMvc.perform(get("/api/v1/pagos/fechaPago/2026-06-21"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));

        verify(service).buscarPorFecha(LocalDate.of(2026, 6, 21));
    }

    @Test
    void deberiaBuscarPorMetodoPago() throws Exception {

        Pago p1 = new Pago();
        p1.setId(1L);
        p1.setMetodoPago("Transferencia");

        when(service.buscarPorMetodoPago("Transferencia"))
                .thenReturn(List.of(p1));

        mockMvc.perform(get("/api/v1/pagos/metodoPago/Transferencia"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].metodoPago").value("Transferencia"));

        verify(service).buscarPorMetodoPago("Transferencia");
    }

    @Test
    void deberiaBorrarPago() throws Exception {

        mockMvc.perform(delete("/api/v1/pagos/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarPorId(1L);
    }
}