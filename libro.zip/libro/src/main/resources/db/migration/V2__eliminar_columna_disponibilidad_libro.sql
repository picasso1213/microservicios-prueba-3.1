ALTER TABLE libro
    DROP COLUMN disponibilidad;
