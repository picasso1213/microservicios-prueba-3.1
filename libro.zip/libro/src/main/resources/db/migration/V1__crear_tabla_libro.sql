CREATE TABLE libro (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    isbn VARCHAR(100),
    titulo_libro VARCHAR(250),
    id_autor BIGINT,
    genero VARCHAR(100),
    edad_recomendada VARCHAR(3),
    cantidad_paginas INT,
    editorial VARCHAR(100),
    anno_publicacion VARCHAR(10),
    disponibilidad BIT,
    estado VARCHAR(100)
);