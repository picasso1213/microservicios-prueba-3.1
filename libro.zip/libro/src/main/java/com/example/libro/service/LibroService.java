package com.example.libro.service;

import com.example.libro.model.Libro;
import com.example.libro.repository.LibroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LibroService {

    @Autowired
    private LibroRepository repository;

    public List<Libro> listar() {
        return repository.findAll();
    }

    public Optional<Libro> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarLibroPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Libro guardarLibro(Libro libro) {
        return repository.save(libro);
    }

    public Libro actualizarLibro(Libro nuevoLibro){
        return repository.save(nuevoLibro);
    }

    //***pruebas de busquedas***

    public List<Libro> buscarPorGenero(String genero) {
        return repository.findByGenero(genero);
    }

    public List<Libro> buscarPorannoPublicacion(String annoPublicacion) {
        return repository.findByAnnoPublicacion(annoPublicacion);
    }

    public List<Libro> buscarPorEdadRecomendada(int edadRecomendada) {
        return repository.findByEdadRecomendada(edadRecomendada);
    }

}
