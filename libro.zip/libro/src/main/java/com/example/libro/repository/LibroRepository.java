package com.example.libro.repository;

import com.example.libro.model.Libro;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LibroRepository extends JpaRepository<Libro, Long> {

    List<Libro> findByGenero(String genero);

    List<Libro> findByAnnoPublicacion(String annoPublicacion);

    List<Libro> findByEdadRecomendada(int edadRecomendada);

}
