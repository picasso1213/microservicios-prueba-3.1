package com.example.libro.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un libro registrado en el sistema")
public class Libro extends RepresentationModel<Libro> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico del libro",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @NotBlank
    @Schema(
            description = "ISBN del libro",
            example = "978-607-8764-83-9",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String isbn;
    @NotBlank
    @Schema(
            description = "Nombre del libro",
            example = "Cien sonetos de amor",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String tituloLibro;
    @NotNull
    @Schema(
            description = "Identificador unico del autor o autora del libro",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idAutor;
    @NotBlank
    @Schema(
            description = "Genero literario del libro",
            example = "Fantasia",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String genero;
    @NotNull
    @Schema(
            description = "Rango etario recomendado para la lectura del libro",
            example = "15-25",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private int edadRecomendada;
    @NotNull
    @Schema(
            description = "Catnidad de paginas totales del libro",
            example = "302",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private int cantidadPaginas;
    @NotBlank
    @Schema(
            description = "Editorial responsable de la comercializacion del libro",
            example = "Editorial Losada",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String editorial;
    @NotBlank
    @Schema(
            description = "Año en el que fue publicado originalmente el libro",
            example = "1965",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String annoPublicacion;
    @NotBlank
    @Schema(
            description = "Estado de conservacion en el que se encuentra el libro",
            example = "Nuevo",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estado;
}
