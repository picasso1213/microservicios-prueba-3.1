package com.example.libro.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.libro.client.AutorClient;
import com.example.libro.model.Libro;
import com.example.libro.service.LibroService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/libros")
@RequiredArgsConstructor
public class LibroController {

    private final AutorClient autorClient;
    @Autowired
    private final LibroService service;

    @Operation(
            summary = "Crear libro",
            description = "Registrar un nuevo libro dentro del sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Libro registrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public Mono<ResponseEntity<Libro>> crearLibro(@Valid @RequestBody Libro libro) {
        return autorClient.obtenerAutor(libro.getIdAutor())
                .map(autor -> {
                    Libro guardado = service.guardarLibro(libro);
                    guardado.add(linkTo(methodOn(LibroController.class).listar()).withRel("mostrar todos los libros"));
                    guardado.add(linkTo(methodOn(LibroController.class).actualizarLibro(guardado)).withRel("actualizar libro"));
                    guardado.add(linkTo(methodOn(LibroController.class).borrarPorId(guardado.getId())).withRel("borrar libro"));
                    guardado.add(linkTo(methodOn(LibroController.class).buscarPorId(guardado.getId())).withSelfRel());
                    return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
                });
    }

    @Operation(
            summary = "Listar libros",
            description = "Muestra una lista con todos los libros registrados en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Libros obtenidos correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Libro> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca un libro dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Libro encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Libro no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Libro> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(libro -> {
                    libro.add(linkTo(methodOn(LibroController.class).listar()).withRel("mostrar todos los libros"));
                    libro.add(linkTo(methodOn(LibroController.class).actualizarLibro(libro)).withRel("actualizar libro"));
                    libro.add(linkTo(methodOn(LibroController.class).borrarPorId(libro.getId())).withRel("borrar libro"));
                    return ResponseEntity.ok(libro);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por genero",
            description = "Muestra una lista de Libros cuyo genero coincida con el genero buscado."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Libros encontrados correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron libros con el genero indicado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/genero/{genero}")
    public ResponseEntity<List<Libro>> buscarPorGenero(@PathVariable String genero) {
        List<Libro> libros = service.buscarPorGenero(genero);
        if(libros.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            libros.forEach(libro -> {
                libro.add(linkTo(methodOn(LibroController.class).listar()).withRel("mostrar todos los libros"));
                libro.add(linkTo(methodOn(LibroController.class).actualizarLibro(libro)).withRel("actualizar libro"));
                libro.add(linkTo(methodOn(LibroController.class).borrarPorId(libro.getId())).withRel("borrar libro"));
            });
            return ResponseEntity.ok(libros);
        }
    }

    @Operation(
            summary = "Buscar por edad",
            description = "Muestra una lista de Libros cuya edad recomendada coincida con la edad buscada."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Libros encontrados correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron recomendaciones de libros para esta edad"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/edadRecomendada/{edadRecomendada}")
    public ResponseEntity<List<Libro>> buscarPoredad(@PathVariable int edadRecomendada) {
        List<Libro> libros = service.buscarPorEdadRecomendada(edadRecomendada);
        if(libros.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            libros.forEach(libro -> {
                libro.add(linkTo(methodOn(LibroController.class).listar()).withRel("mostrar todos los libros"));
                libro.add(linkTo(methodOn(LibroController.class).actualizarLibro(libro)).withRel("actualizar libro"));
                libro.add(linkTo(methodOn(LibroController.class).borrarPorId(libro.getId())).withRel("borrar libro"));
            });
            return ResponseEntity.ok(libros);
        }
    }

    @Operation(
            summary = "Actualizar libro",
            description = "Actualiza los datos de un libro."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Libro actualizado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Libro no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Libro> actualizarLibro(@Valid @RequestBody Libro nuevoLibro) {
        Libro libroActualizado = service.actualizarLibro(nuevoLibro);
        libroActualizado.add(linkTo(methodOn(LibroController.class).listar()).withRel("mostrar todos los libros"));
        libroActualizado.add(linkTo(methodOn(LibroController.class).actualizarLibro(libroActualizado)).withRel("actualizar libro"));
        libroActualizado.add(linkTo(methodOn(LibroController.class).borrarPorId(libroActualizado.getId())).withRel("borrar libro"));
        return ResponseEntity.ok(libroActualizado);
    }

    @Operation(
            summary = "Borrar libro",
            description = "Se borra un libro del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Libro eliminado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Libro no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try{
            service.borrarLibroPorId(id);
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }

}
