package com.example.libro.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Schema(description = "Entidad que representa los datos de un autor en el sistema")
public class Autor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico del autor o autora",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @NotBlank
    @Schema(
            description = "Nombre del autor o autora",
            example = "Pablo Neruda",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String nombreAutor;
    @NotBlank
    @Schema(
            description = "Fecha de nacimiento del autor o autora",
            example = "1904-07-12",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String fechaNacimiento;
    @Schema(
            description = "Fecha de fallecimiento del autor o autora",
            example = "1973-09-23"
    )
    private String fechaFallecimiento;
    @NotBlank
    @Schema(
            description = "Genero literario principal del autor o autora",
            example = "Fantasia",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String generoPrincipal;
    @NotBlank
    @Schema(
            description = "Biografia resumida del autor o autora",
            example = "Poeta chileno, premio Nobel de Literatura en 1971"
    )
    private String biografia;
    @NotBlank
    @Schema(
            description = "Nacionalidad del autor o autora",
            example = "Chilena",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String nacionalidad;
}
