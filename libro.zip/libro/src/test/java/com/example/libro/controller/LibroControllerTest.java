package com.example.libro.controller;

import com.example.libro.client.AutorClient;
import com.example.libro.model.Autor;
import com.example.libro.model.Libro;
import com.example.libro.service.LibroService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LibroController.class)
@AutoConfigureMockMvc(addFilters = false)
class LibroControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private LibroService service;

    @MockitoBean
    private AutorClient autorClient;

    @Test
    void deberiaRetornarLibroPorId() throws Exception {

        Libro libro = new Libro();
        libro.setId(1L);
        libro.setIsbn("978-607-8764-83-9");
        libro.setTituloLibro("Cien sonetos de amor");
        libro.setIdAutor(1L);
        libro.setGenero("Poesia");
        libro.setEdadRecomendada(15);
        libro.setCantidadPaginas(120);
        libro.setEditorial("Editorial Losada");
        libro.setAnnoPublicacion("1959");
        libro.setEstado("Nuevo");

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(libro));

        mockMvc.perform(get("/api/v1/libros/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.tituloLibro").value("Cien sonetos de amor"));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearLibro() throws Exception {

        Autor autor = new Autor();
        autor.setId(1L);
        autor.setNombreAutor("Pablo Neruda");

        Libro libro = new Libro();
        libro.setId(1L);
        libro.setIsbn("978-607-8764-83-9");
        libro.setTituloLibro("Cien sonetos de amor");
        libro.setIdAutor(1L);
        libro.setGenero("Poesia");
        libro.setEdadRecomendada(15);
        libro.setCantidadPaginas(120);
        libro.setEditorial("Editorial Losada");
        libro.setAnnoPublicacion("1959");
        libro.setEstado("Nuevo");

        when(autorClient.obtenerAutor(1L))
                .thenReturn(Mono.just(autor));

        when(service.guardarLibro(any(Libro.class)))
                .thenReturn(libro);

        String json = """
                {
                    "isbn": "978-607-8764-83-9",
                    "tituloLibro": "Cien sonetos de amor",
                    "idAutor": 1,
                    "genero": "Poesia",
                    "edadRecomendada": 15,
                    "cantidadPaginas": 120,
                    "editorial": "Editorial Losada",
                    "annoPublicacion": "1959",
                    "estado": "Nuevo"
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/libros")
                        .contentType("application/json")
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.tituloLibro").value("Cien sonetos de amor"))
                .andExpect(jsonPath("$.isbn").value("978-607-8764-83-9"));

        verify(autorClient).obtenerAutor(1L);
        verify(service).guardarLibro(any(Libro.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "tituloLibro": "Libro incompleto"
                }
                """;

        mockMvc.perform(post("/api/v1/libros")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarLibros() throws Exception {

        Libro l1 = new Libro();
        l1.setId(1L);
        l1.setTituloLibro("Cien sonetos de amor");

        when(service.listar())
                .thenReturn(List.of(l1));

        mockMvc.perform(get("/api/v1/libros"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].tituloLibro").value("Cien sonetos de amor"));

        verify(service).listar();
    }

    @Test
    void deberiaBuscarPorGenero() throws Exception {

        Libro l1 = new Libro();
        l1.setId(1L);
        l1.setTituloLibro("Cien sonetos de amor");
        l1.setGenero("Poesia");

        when(service.buscarPorGenero("Poesia"))
                .thenReturn(List.of(l1));

        mockMvc.perform(get("/api/v1/libros/genero/Poesia"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].genero").value("Poesia"));

        verify(service).buscarPorGenero("Poesia");
    }

    @Test
    void deberiaBorrarLibro() throws Exception {

        mockMvc.perform(delete("/api/v1/libros/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarLibroPorId(1L);
    }
}
