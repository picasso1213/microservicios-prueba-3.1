package com.example.libro.service;

import com.example.libro.model.Libro;
import com.example.libro.repository.LibroRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class LibroServiceTest {

    @Mock
    private LibroRepository repository;

    @InjectMocks
    private LibroService service;

    @Test
    void deberiaRetornarLibroCuandoExiste() {

        Libro libro = new Libro();
        libro.setId(1L);
        libro.setIsbn("978-607-8764-83-9");
        libro.setTituloLibro("Cien sonetos de amor");
        libro.setIdAutor(1L);
        libro.setGenero("Poesia");
        libro.setEdadRecomendada(15);
        libro.setCantidadPaginas(120);
        libro.setEditorial("Editorial Losada");
        libro.setAnnoPublicacion("1959");
        libro.setEstado("Nuevo");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(libro));

        Optional<Libro> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Cien sonetos de amor", resultado.get().getTituloLibro());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarLibro() {

        Libro libro = new Libro();
        libro.setIsbn("978-0-307-47472-7");
        libro.setTituloLibro("Cien años de soledad");
        libro.setIdAutor(2L);
        libro.setGenero("Novela");
        libro.setEdadRecomendada(16);
        libro.setCantidadPaginas(471);
        libro.setEditorial("Editorial Sudamericana");
        libro.setAnnoPublicacion("1967");
        libro.setEstado("Nuevo");

        Mockito.when(repository.save(libro))
                .thenReturn(libro);

        Libro guardado = service.guardarLibro(libro);

        assertEquals("Cien años de soledad", guardado.getTituloLibro());

        verify(repository).save(libro);
    }
}
