package com.example.autor.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.autor.model.Autor;
import com.example.autor.repository.AutorRepository;
import com.example.autor.service.AutorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import jakarta.validation.constraints.FutureOrPresent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/autores")
public class AutorController {

    @Autowired
    private AutorService service;

    @Operation(
            summary = "Crear autor",
            description = "Registrar nuevo autor en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Autor registrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public ResponseEntity<Autor> guardarAutor(@RequestBody @Valid Autor nuevoAutor) {
        service.guardarAutor(nuevoAutor);
        nuevoAutor.add(linkTo(methodOn(AutorController.class).listar()).withRel("mostrar todos los autores"));
        nuevoAutor.add(linkTo(methodOn(AutorController.class).buscarPorId(nuevoAutor.getId())).withSelfRel());
        nuevoAutor.add(linkTo(methodOn(AutorController.class).borrarAutorPorId(nuevoAutor.getId())).withRel("borrar un autor"));
        nuevoAutor.add(linkTo(methodOn(AutorController.class).actualizarAutor(nuevoAutor)).withRel("actualizar un autor"));
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoAutor);
    }

    @Operation(
            summary = "Listar autores",
            description = "Muestra una lista con todos los autores registrados en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Autores obtenidos correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Autor> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca un autor dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Autor encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Autor no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Autor> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(autor -> {
                    autor.add(linkTo(methodOn(AutorController.class).listar()).withRel("mostrar todos los autores"));
                    autor.add(linkTo(methodOn(AutorController.class).actualizarAutor(autor)).withRel("actualizar autor"));
                    autor.add(linkTo(methodOn(AutorController.class).borrarAutorPorId(id)).withRel("borrar autor"));
                    return ResponseEntity.ok(autor);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por genero principal",
            description = "Muestra una lista de autores cuyo genero principal coincida con el genero buscado."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Autores encontrados correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron autores del genero indicado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/generoPrincipal/{generoPrincipal}")
    public ResponseEntity<List<Autor>> buscarPorGenero(@PathVariable String generoPrincipal) {
        List<Autor> autores = service.buscarPorGenero(generoPrincipal);
        if (autores.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            autores.forEach(autor -> {
                autor.add(linkTo(methodOn(AutorController.class).listar()).withRel("mostrar todos los autores"));
                autor.add(linkTo(methodOn(AutorController.class).actualizarAutor(autor)).withRel("actualizar autor"));
                autor.add(linkTo(methodOn(AutorController.class).borrarAutorPorId(autor.getId())).withRel("borrar autor"));
            });
            return ResponseEntity.ok(autores);
        }
    }

    @Operation(
            summary = "Buscar por nacionalidad",
            description = "Muestra una lista de autores cuya nacionalidad coincida con la nacionalidad buscada."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Autores encontrados correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron autores de la nacionalidad indicada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/nacionalidad/{nacionalidad}")
    public ResponseEntity<List<Autor>> buscarPorNacionalidad(@PathVariable String nacionalidad) {
        List<Autor> autores = service.buscarPorNacionalidad(nacionalidad);
        if (autores.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            autores.forEach(autor -> {
                autor.add(linkTo(methodOn(AutorController.class).listar()).withRel("mostrar todos los autores"));
                autor.add(linkTo(methodOn(AutorController.class).actualizarAutor(autor)).withRel("actualizar autor"));
                autor.add(linkTo(methodOn(AutorController.class).borrarAutorPorId(autor.getId())).withRel("borrar autor"));
            });
            return ResponseEntity.ok(autores);
        }
    }

    @Operation(
            summary = "Actualizar autor",
            description = "Actualiza los datos de un autor."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Autor actualizado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Autor no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Autor> actualizarAutor(@Valid @RequestBody Autor nuevoAutor) {
        Autor autorActualizado = service.actualizarAutor(nuevoAutor);
        autorActualizado.add(linkTo(methodOn(AutorController.class).listar()).withRel("mostrar todos los autores"));
        autorActualizado.add(linkTo(methodOn(AutorController.class).buscarPorId(autorActualizado.getId())).withSelfRel());
        autorActualizado.add(linkTo(methodOn(AutorController.class).borrarAutorPorId(autorActualizado.getId())).withRel("borrar autor"));
        return ResponseEntity.ok(autorActualizado);
    }

    @Operation(
            summary = "Borrar autor",
            description = "Se borra un autor del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Autor eliminado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Autor no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("{id}")
    public ResponseEntity<Void> borrarAutorPorId(@PathVariable Long id) {
        try {
            service.borrarPorId(id);
        } catch (NoSuchElementException ex) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }


}
