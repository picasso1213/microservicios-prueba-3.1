package com.example.autor.repository;

import com.example.autor.model.Autor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AutorRepository extends JpaRepository<Autor, Long> {

    List<Autor> findByGeneroPrincipal(String genero);

    List<Autor> findByNacionalidad(String nacionalidad);

}
