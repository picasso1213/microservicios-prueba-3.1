package com.example.autor.service;

import com.example.autor.model.Autor;
import com.example.autor.repository.AutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AutorService {

    @Autowired
    private AutorRepository repository;

    public List<Autor> listar() {
        return repository.findAll();
    }

    public Optional<Autor> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public void guardarAutor(Autor nuevoAutor) {
        repository.save(nuevoAutor);
    }

    public Autor actualizarAutor(Autor nuevoAutor) {
        return repository.save(nuevoAutor);
    }

    public List<Autor> buscarPorGenero(String genero) {
        return repository.findByGeneroPrincipal(genero);
    }

    public List<Autor> buscarPorNacionalidad(String nacionalidad) {
        return repository.findByNacionalidad(nacionalidad);
    }


}
