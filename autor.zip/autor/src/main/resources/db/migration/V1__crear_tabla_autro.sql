CREATE TABLE autor(
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    nombre_autor VARCHAR(100),
    fecha_nacimiento VARCHAR(100),
    fecha_fallecimiento VARCHAR(100),
    genero_principal VARCHAR(100),
    biografia VARCHAR(250),
    nacionalidad VARCHAR(100)
);