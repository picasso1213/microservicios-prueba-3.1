INSERT INTO autor (
    id,
    nombre_autor,
    fecha_nacimiento,
    fecha_fallecimiento,
    genero_principal,
    biografia,
    nacionalidad
)
VALUES (
    1,
    'Pablo Neruda',
    '1904-07-12',
    '1973-09-23',
    'Poesia',
    'Poeta chileno, premio Nobel de Literatura en 1971',
    'Chilena'
);