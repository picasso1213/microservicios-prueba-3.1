package com.example.multa.service;

import com.example.multa.model.Multa;
import com.example.multa.repository.MultaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class MultaServiceTest {

    @Mock
    private MultaRepository repository;

    @Mock
    private com.example.multa.client.RetrasoClient retrasoClient;

    @InjectMocks
    private MultaService service;

    @Test
    void deberiaRetornarMultaCuandoExiste() {

        Multa multa = new Multa();
        multa.setId(1L);
        multa.setIdUsuario(5L);
        multa.setIdRetraso(3L);
        multa.setCalculoMulta(5000);
        multa.setEstadoMulta("Pendiente");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(multa));

        Optional<Multa> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Pendiente", resultado.get().getEstadoMulta());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarMulta() {

        Multa multa = new Multa();
        multa.setIdUsuario(5L);
        multa.setIdRetraso(3L);
        multa.setCalculoMulta(3000);
        multa.setEstadoMulta("Pagada");

        Mockito.when(repository.save(multa))
                .thenReturn(multa);

        Multa guardada = service.guardarMulta(multa);

        assertEquals("Pagada", guardada.getEstadoMulta());

        verify(repository).save(multa);
    }
}
