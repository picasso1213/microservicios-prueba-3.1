package com.example.multa.controller;

import com.example.multa.client.UsuarioClient;
import com.example.multa.model.Multa;
import com.example.multa.model.Usuario;
import com.example.multa.service.MultaService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(MultaController.class)
@AutoConfigureMockMvc(addFilters = false)
class MultaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private MultaService service;

    @MockitoBean
    private UsuarioClient usuarioClient;

    @Test
    void deberiaRetornarMultaPorId() throws Exception {

        Multa multa = new Multa();
        multa.setId(1L);
        multa.setIdUsuario(5L);
        multa.setIdRetraso(3L);
        multa.setCalculoMulta(5000);
        multa.setEstadoMulta("Pendiente");

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(multa));

        mockMvc.perform(get("/api/v1/multas/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.estadoMulta").value("Pendiente"));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearMulta() throws Exception {

        Usuario usuario = new Usuario();
        usuario.setId(5L);

        Multa multa = new Multa();
        multa.setId(1L);
        multa.setIdUsuario(5L);
        multa.setIdRetraso(3L);
        multa.setCalculoMulta(3000);
        multa.setEstadoMulta("Pendiente");

        when(service.calcularMulta(3L))
                .thenReturn(Mono.just(3000));

        when(usuarioClient.obtenerUsuario(5L))
                .thenReturn(Mono.just(usuario));

        when(service.guardarMulta(any(Multa.class)))
                .thenReturn(multa);

        String json = """
                {
                    "idUsuario": 5,
                    "idRetraso": 3,
                    "estadoMulta": "Pendiente"
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/multas")
                        .contentType("application/json")
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.calculoMulta").value(3000))
                .andExpect(jsonPath("$.estadoMulta").value("Pendiente"));

        verify(service).calcularMulta(3L);
        verify(usuarioClient).obtenerUsuario(5L);
        verify(service).guardarMulta(any(Multa.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "calculoMulta": 3000
                }
                """;

        mockMvc.perform(post("/api/v1/multas")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarMultas() throws Exception {

        Multa m1 = new Multa();
        m1.setId(1L);
        m1.setEstadoMulta("Pendiente");

        when(service.listar())
                .thenReturn(List.of(m1));

        mockMvc.perform(get("/api/v1/multas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));

        verify(service).listar();
    }

    @Test
    void deberiaBuscarPorEstado() throws Exception {

        Multa m1 = new Multa();
        m1.setId(1L);
        m1.setEstadoMulta("Pagada");

        when(service.buscarPorEstado("Pagada"))
                .thenReturn(List.of(m1));

        mockMvc.perform(get("/api/v1/multas/estadoMulta/Pagada"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].estadoMulta").value("Pagada"));

        verify(service).buscarPorEstado("Pagada");
    }

    @Test
    void deberiaBorrarMulta() throws Exception {

        mockMvc.perform(delete("/api/v1/multas/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarPorId(1L);
    }
}
