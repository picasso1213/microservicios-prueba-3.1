package com.example.multa.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.multa.client.UsuarioClient;
import com.example.multa.model.Multa;
import com.example.multa.model.Usuario;
import com.example.multa.service.MultaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/multas")
@RequiredArgsConstructor
public class MultaController {

    private final UsuarioClient usuarioClient;
    @Autowired
    private final MultaService service;

    @Operation(
            summary = "Crear multa",
            description = "Registrar una nueva multa dentro del sistema"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Multa registrada correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public Mono<ResponseEntity<Multa>> guardarMulta2(@Valid @RequestBody Multa multa) {
        return service.calcularMulta(multa.getIdRetraso())
                .flatMap(calculo -> usuarioClient.obtenerUsuario(multa.getIdUsuario())
                        .map(usuario -> {
                            multa.setCalculoMulta(calculo);
                            Multa guardada = service.guardarMulta(multa);
                            guardada.add(linkTo(methodOn(MultaController.class).listar()).withRel("mostrar todas las multas"));
                            guardada.add(linkTo(methodOn(MultaController.class).buscarPorId(guardada.getId())).withSelfRel());
                            guardada.add(linkTo(methodOn(MultaController.class).borrarPorId(guardada.getId())).withRel("borrar multa"));
                            guardada.add(linkTo(methodOn(MultaController.class).actualizarMulta(guardada)).withRel("actulizar multa"));
                            return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
                        })
                );
    }

    @Operation(
            summary = "Listar multas",
            description = "Muestra una lista con todas las multas registradas en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Multas obtenidas correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Multa> listar(){
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca una multa dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Multa encontrada correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Multa no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Multa> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(multa -> {
                    multa.add(linkTo(methodOn(MultaController.class).listar()).withRel("mostrar todas las multas"));
                    multa.add(linkTo(methodOn(MultaController.class).borrarPorId(multa.getId())).withRel("borrar multa"));
                    multa.add(linkTo(methodOn(MultaController.class).actualizarMulta(multa)).withRel("actulizar multa"));
                    return ResponseEntity.ok(multa);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por estado multa",
            description = "Muestra una lista de multas cuyo estado de pago coincida con el buscado."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Multas encontradas correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron multas en la fecha indicada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/estadoMulta/{estadoMulta}")
    public ResponseEntity<List<Multa>> buscarPorEstado(@PathVariable String estadoMulta){
        List<Multa> multas = service.buscarPorEstado(estadoMulta);
        if(multas.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            multas.forEach(multa -> {
                multa.add(linkTo(methodOn(MultaController.class).listar()).withRel("mostrar todas las multas"));
                multa.add(linkTo(methodOn(MultaController.class).borrarPorId(multa.getId())).withRel("borrar multa"));
                multa.add(linkTo(methodOn(MultaController.class).actualizarMulta(multa)).withRel("actulizar multa"));
            });
            return ResponseEntity.ok(multas);
        }
    }

    @Operation(
            summary = "Actualizar multa",
            description = "Actualiza los datos de una multa."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Multa actualizada correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Multa no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Multa> actualizarMulta(@RequestBody Multa multa) {
        Multa muActualizada = service.actualizarMulta(multa);
        muActualizada.add(linkTo(methodOn(MultaController.class).listar()).withRel("mostrar todas las multas"));
        muActualizada.add(linkTo(methodOn(MultaController.class).borrarPorId(muActualizada.getId())).withRel("borrar multa"));
        muActualizada.add(linkTo(methodOn(MultaController.class).actualizarMulta(muActualizada)).withRel("actulizar multa"));
        return ResponseEntity.ok(muActualizada);
    }

    @Operation(
            summary = "Borrar multa",
            description = "Se borra una multa del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Multa eliminada correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Multa no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try{
            service.borrarPorId(id);
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }



}
