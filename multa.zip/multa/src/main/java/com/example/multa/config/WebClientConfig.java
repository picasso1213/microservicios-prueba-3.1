package com.example.multa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Value("${retraso.service.url:http://localhost:9097}")
    private String retrasoServiceUrl;

    @Value("${usuario.service.url:http://localhost:9090}")
    private String usuarioServiceUrl;

    @Bean
    public WebClient webClient(){
        return WebClient.builder()
                .baseUrl(retrasoServiceUrl) //Microservicio Retraso
                .build();
    }

    @Bean
    public WebClient usuarioWebClient(){
        return WebClient.builder()
                .baseUrl(usuarioServiceUrl) //Microservicio Usuario
                .build();
    }
}