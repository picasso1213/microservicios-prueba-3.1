package com.example.multa.client;

import com.example.multa.model.Retraso;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class RetrasoClient {

    private final WebClient webClient;

    public Mono<Retraso> obtenerRetraso(Long id) {
        return webClient.get()
                .uri("/api/v1/retrasos/id/" + id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError,reponse ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "retraso no encontrado"
                        ))
                )
                .bodyToMono(Retraso.class);
    }

}
