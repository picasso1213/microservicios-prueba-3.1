package com.example.multa.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

import javax.swing.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa una multa registrada en le sistema")
public class Multa extends RepresentationModel<Multa> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico de la multa",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @NotNull
    @Schema(
            description = "Identificador unico del usuario que resive la multa",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idUsuario;
    @NotNull
    @Schema(
            description = "Identificador unico del retrado asociado a la multa",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idRetraso;
    @Schema(
            description = "Monto a pagar, basado en los dias de retraso",
            example = "3.000",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Integer calculoMulta;
    @NotBlank
    @Schema(
            description = "Estado en el que se encuentra la multa",
            example = "Pagada",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estadoMulta;

}
