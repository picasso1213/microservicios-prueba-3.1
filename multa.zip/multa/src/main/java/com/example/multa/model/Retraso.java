package com.example.multa.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.hateoas.RepresentationModel;

@Data
@Schema(description = "Entidad que representa los datos del retraso relacionado a la multa")
public class Retraso{

    @Schema(
            description = "Identificador unico del retraso",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @Schema(
            description = "Identifcador unico del prestamo relacionado al retraso",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idPrestamo;
    @Schema(
            description = "Identifcador unico de la devolucion relacionada al prestamo",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idDevolucion;
    @Schema(
            description = "Calculo de dias entre el termino del prestamo y la devolucion de un libro",
            example = "15",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Integer diasRetraso;

}