package com.example.multa.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;

@Data
@Schema(description = "Entidad que representa los datos de un usuario registrado en el sistema")
public class Usuario {

    @Schema(
            description = "Identificador unico del usuario",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @Schema(
            description = "Nombre del usuario",
            example = "Tomás Nunez Flores",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String nombreUsuario;
    @Schema(
            description = "RUT del usuario",
            example = "22163515-9",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String rutUsuario;
    @Schema(
            description = "Telefono de contacto del usuario",
            example = "920851576",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String telefonoUsuario;
    @Schema(
            description = "Correo de contacto del usuario",
            example = "to.nunezf@duocuc.cl",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String correoUsuario;
    @Schema(
            description = "Fecha de nacimiento del usuario",
            example = "2026-07-18"
    )
    private LocalDate fechaNacimiento;


}
