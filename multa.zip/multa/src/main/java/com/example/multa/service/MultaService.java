package com.example.multa.service;

import com.example.multa.client.RetrasoClient;
import com.example.multa.model.Multa;
import com.example.multa.repository.MultaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MultaService {

    private final RetrasoClient retrasoClient;
    @Autowired
    private final MultaRepository repository;


    public Mono<Integer> calcularMulta(Long idRetraso) {
        return retrasoClient.obtenerRetraso(idRetraso)
                .map(retraso -> retraso.getDiasRetraso() * 1000);
    }

    public List<Multa> listar(){
        return repository.findAll();
    }

    public Optional<Multa> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Multa guardarMulta(Multa multa) {
        return repository.save(multa);
    }

    public Multa actualizarMulta(Multa multa) {
        return repository.save(multa);
    }

    public List<Multa> buscarPorEstado(String estadoMulta) {
        return repository.findByEstadoMulta(estadoMulta);
    }


}
