package com.example.multa.client;

import com.example.multa.model.Retraso;
import com.example.multa.model.Usuario;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class UsuarioClient {

    private final WebClient usuarioWebClient;

    public Mono<Usuario> obtenerUsuario(Long id) {
        return usuarioWebClient.get()
                .uri("/api/v1/usuarios/id/" + id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, reponse ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "usuario no encontrado"
                        ))
                )
                .bodyToMono(Usuario.class);
    }

}
