package com.example.multa.repository;

import com.example.multa.model.Multa;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MultaRepository extends JpaRepository<Multa, Long> {
    List<Multa> findByEstadoMulta(String estadoMulta);
}
