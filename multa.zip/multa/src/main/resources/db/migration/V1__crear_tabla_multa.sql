CREATE TABLE multa(
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_devolucion BIGINT,
    id_retraso BIGINT,
    calculo_multa INT,
    estado_multa VARCHAR(50)
)