ALTER TABLE multa
    DROP COLUMN id_devolucion;