ALTER TABLE multa
    ADD COLUMN id_usuario BIGINT;