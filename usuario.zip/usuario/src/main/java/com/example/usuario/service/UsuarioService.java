package com.example.usuario.service;

import com.example.usuario.model.Usuario;
import com.example.usuario.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    public List<Usuario> listar() {
        return repository.findAll();
    }

    public Optional<Usuario> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarUsuarioPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Usuario guardarUsuario(Usuario nuevoUsuario) {
        return repository.save(nuevoUsuario);
    }

    public Usuario actualizarUsuario(Usuario nuevoUsuario) {
        return repository.save(nuevoUsuario);
    }

    public List<Usuario> buscarPorRut(String rutUsuario) {
        return repository.findByRutUsuario(rutUsuario);
    }

}
