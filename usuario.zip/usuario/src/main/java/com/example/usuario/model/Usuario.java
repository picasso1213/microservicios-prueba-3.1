package com.example.usuario.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa a un usuario registrado en el sistema.")
public class Usuario extends RepresentationModel<Usuario> {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico del usuario",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @NotBlank
    @Schema(
            description = "Nombre del usuario",
            example = "Tomás Nunez Flores",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String nombreUsuario;
    @NotBlank
    @Schema(
            description = "RUT del usuario",
            example = "22163515-9",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String rutUsuario;
    @NotBlank
    @Schema(
            description = "Telefono de contacto del usuario",
            example = "920851576",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String telefonoUsuario;
    @NotBlank
    @Schema(
            description = "Correo de contacto del usuario",
            example = "to.nunezf@duocuc.cl",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String correoUsuario;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Schema(
            description = "Fecha de nacimiento del usuario",
            example = "2026-07-18"
    )
    private LocalDate fechaNacimiento;

}
