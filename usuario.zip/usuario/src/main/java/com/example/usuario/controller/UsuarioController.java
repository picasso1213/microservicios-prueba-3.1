package com.example.usuario.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.usuario.model.Usuario;
import com.example.usuario.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService service;


    @Operation(
            summary = "Crear usuario",
            description = "Registra un usuario en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Usuario creado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public ResponseEntity<Usuario> guardarUsuario(@RequestBody @Valid Usuario nuevoUsuario) {
        Usuario us = service.guardarUsuario(nuevoUsuario);
        us.add(linkTo(methodOn(UsuarioController.class).listar()).withRel("mostrar todos los usuarios"));
        us.add(linkTo(methodOn(UsuarioController.class).buscarPorId(us.getId())).withSelfRel());
        us.add(linkTo(methodOn(UsuarioController.class).buscarPorRut(us.getRutUsuario())).withRel("buscar por rut"));
        us.add(linkTo(methodOn(UsuarioController.class).borrarUsuarioPorid(us.getId())).withRel("borrar usuario por ID"));
        us.add(linkTo(methodOn(UsuarioController.class).actualizarUsuario(us)).withRel("actualizar usuario"));
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoUsuario);
    }

    @Operation(
            summary = "Listar usuarios",
            description = "Muestra una lista con los datos de los usuarios registrados en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Usuario obtenidos correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Usuario> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca un usuario dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Usuario> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(usuario -> {
                    usuario.add(linkTo(methodOn(UsuarioController.class).listar()).withRel("mostrar todos los usuarios"));
                    usuario.add(linkTo(methodOn(UsuarioController.class).actualizarUsuario(usuario)).withRel("actualizar usuario"));
                    usuario.add(linkTo(methodOn(UsuarioController.class).borrarUsuarioPorid(usuario.getId())).withRel("borrar usuario por ID"));
                    return ResponseEntity.ok(usuario);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por RUT",
            description = "Busca un usuario dentro del sistema en base a su RUT."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/rutUsuario/{rutUsuario}")
    public ResponseEntity<List<Usuario>> buscarPorRut(@PathVariable String rutUsuario) {
        List<Usuario> usuarios = service.buscarPorRut(rutUsuario);
        if(usuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            usuarios.forEach(usuario -> {
                usuario.add(linkTo(methodOn(UsuarioController.class).listar()).withRel("mostrar todos los usuarios"));
                usuario.add(linkTo(methodOn(UsuarioController.class).actualizarUsuario(usuario)).withRel("actualizar usuario"));
                usuario.add(linkTo(methodOn(UsuarioController.class).borrarUsuarioPorid(usuario.getId())).withRel("borrar usuario por ID"));
            });
            return ResponseEntity.ok(usuarios);
        }
    }

    @Operation(
            summary = "Actualizar usuario",
            description = "Actualiza los datos de un usuario."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario actualizado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Usuario> actualizarUsuario(@Valid @RequestBody Usuario usuario) {
        Usuario usuarioActualizado = service.actualizarUsuario(usuario);
        usuarioActualizado.add(linkTo(methodOn(UsuarioController.class).listar()).withRel("mostrar todos los usuarios"));
        usuarioActualizado.add(linkTo(methodOn(UsuarioController.class).borrarUsuarioPorid(usuarioActualizado.getId())).withRel("eliminar"));
        usuarioActualizado.add(linkTo(methodOn(UsuarioController.class).buscarPorRut(usuarioActualizado.getRutUsuario())).withRel("buscar por rut"));

        return ResponseEntity.ok(usuarioActualizado);
    }

    @Operation(
            summary = "Borrar usuario",
            description = "Se borra un usuario del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Usuario eliminado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("{id}")
    public ResponseEntity<Void> borrarUsuarioPorid(@PathVariable Long id) {
        try {
            service.borrarUsuarioPorId(id);
        }catch (NoSuchElementException ex) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }

}
