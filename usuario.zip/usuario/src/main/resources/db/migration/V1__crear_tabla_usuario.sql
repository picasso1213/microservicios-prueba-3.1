CREATE TABLE usuario (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    nombre_usuario VARCHAR(100),
    rut_usuario VARCHAR(100),
    telefono_usuario VARCHAR(100),
    correo_usuario VARCHAR(100),
    fecha_nacimiento DATE
);