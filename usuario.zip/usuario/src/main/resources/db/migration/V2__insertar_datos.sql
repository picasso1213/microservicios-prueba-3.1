INSERT INTO usuario(
    id,
    nombre_usuario,
    rut_usuario,
    telefono_usuario,
    correo_usuario,
    fecha_nacimiento
)
VALUES(
    1,
    'Tomas Nuñez Flores',
    '22163515-9',
    '920851576',
    'to.nunezf@duocuc.cl',
    '2006-07-18'
);