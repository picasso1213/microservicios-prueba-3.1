package com.example.usuario.controller;

import com.example.usuario.model.Usuario;
import com.example.usuario.service.UsuarioService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsuarioController.class)
@AutoConfigureMockMvc(addFilters = false)
class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private UsuarioService service;

    @Test
    void deberiaRetornarUsuarioPorId() throws Exception {

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombreUsuario("Juan Perez");
        usuario.setRutUsuario("11111111-1");
        usuario.setTelefonoUsuario("912345678");
        usuario.setCorreoUsuario("juan@correo.com");

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(usuario));

        mockMvc.perform(get("/api/v1/usuarios/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nombreUsuario").value("Juan Perez"));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearUsuario() throws Exception {

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombreUsuario("Maria Lopez");
        usuario.setRutUsuario("22222222-2");
        usuario.setTelefonoUsuario("987654321");
        usuario.setCorreoUsuario("maria@correo.com");

        when(service.guardarUsuario(any(Usuario.class)))
                .thenReturn(usuario);

        String json = """
                {
                    "nombreUsuario": "Maria Lopez",
                    "rutUsuario": "22222222-2",
                    "telefonoUsuario": "987654321",
                    "correoUsuario": "maria@correo.com"
                }
                """;

        mockMvc.perform(post("/api/v1/usuarios")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.nombreUsuario").value("Maria Lopez"))
                .andExpect(jsonPath("$.rutUsuario").value("22222222-2"));

        verify(service).guardarUsuario(any(Usuario.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "telefonoUsuario": "987654321"
                }
                """;

        mockMvc.perform(post("/api/v1/usuarios")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarUsuarios() throws Exception {

        Usuario u1 = new Usuario();
        u1.setId(1L);
        u1.setNombreUsuario("Juan Perez");

        when(service.listar())
                .thenReturn(List.of(u1));

        mockMvc.perform(get("/api/v1/usuarios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombreUsuario").value("Juan Perez"));

        verify(service).listar();
    }

    @Test
    void deberiaBorrarUsuario() throws Exception {

        mockMvc.perform(delete("/api/v1/usuarios/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarUsuarioPorId(1L);
    }
}
