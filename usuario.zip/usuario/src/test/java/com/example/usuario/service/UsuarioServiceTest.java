package com.example.usuario.service;

import com.example.usuario.model.Usuario;
import com.example.usuario.repository.UsuarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {

    @Mock
    private UsuarioRepository repository;

    @InjectMocks
    private UsuarioService service;

    @Test
    void deberiaRetornarUsuarioCuandoExiste() {

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombreUsuario("Juan Perez");
        usuario.setRutUsuario("11111111-1");
        usuario.setTelefonoUsuario("912345678");
        usuario.setCorreoUsuario("juan@correo.com");
        usuario.setFechaNacimiento(LocalDate.of(2000, 1, 1));

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(usuario));

        Optional<Usuario> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Juan Perez", resultado.get().getNombreUsuario());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarUsuario() {

        Usuario usuario = new Usuario();
        usuario.setNombreUsuario("Maria Lopez");
        usuario.setRutUsuario("22222222-2");
        usuario.setTelefonoUsuario("987654321");
        usuario.setCorreoUsuario("maria@correo.com");

        Mockito.when(repository.save(usuario))
                .thenReturn(usuario);

        Usuario guardado = service.guardarUsuario(usuario);

        assertEquals("Maria Lopez", guardado.getNombreUsuario());

        verify(repository).save(usuario);
    }
}
