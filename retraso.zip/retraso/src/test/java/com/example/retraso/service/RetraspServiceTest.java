package com.example.retraso.service;

import com.example.retraso.client.DevolucionClient;
import com.example.retraso.client.PrestamoClient;
import com.example.retraso.model.Retraso;
import com.example.retraso.repository.RetrasoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class RetrasoServiceTest {

    @Mock
    private RetrasoRepository repository;

    @Mock
    private PrestamoClient prestamoClient;

    @Mock
    private DevolucionClient devolucionClient;

    private RetrasoService service;

    @BeforeEach
    void setUp() {
        service = new RetrasoService(prestamoClient, devolucionClient);
        ReflectionTestUtils.setField(service, "repository", repository);
    }

    @Test
    void deberiaRetornarRetrasooCuandoExiste() {

        Retraso retraso = new Retraso();
        retraso.setId(1L);
        retraso.setIdPrestamo(3L);
        retraso.setIdDevolucion(7L);
        retraso.setDiasRetraso(5);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(retraso));

        Optional<Retraso> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(5, resultado.get().getDiasRetraso());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarRetraso() {

        Retraso retraso = new Retraso();
        retraso.setIdPrestamo(3L);
        retraso.setIdDevolucion(7L);
        retraso.setDiasRetraso(10);

        Mockito.when(repository.save(retraso))
                .thenReturn(retraso);

        Retraso guardado = service.guardarRetraso(retraso);

        assertEquals(10, guardado.getDiasRetraso());

        verify(repository).save(retraso);
    }
}