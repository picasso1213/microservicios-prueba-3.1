package com.example.retraso.controller;

import com.example.retraso.model.Retraso;
import com.example.retraso.service.RetrasoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RetrasoController.class)
@AutoConfigureMockMvc(addFilters = false)
class RetrasoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private RetrasoService service;

    @Test
    void deberiaRetornarRetrasosPorId() throws Exception {

        Retraso retraso = new Retraso();
        retraso.setId(1L);
        retraso.setIdPrestamo(3L);
        retraso.setIdDevolucion(7L);
        retraso.setDiasRetraso(5);

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(retraso));

        mockMvc.perform(get("/api/v1/retrasos/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.diasRetraso").value(5));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearRetraso() throws Exception {

        Retraso retraso = new Retraso();
        retraso.setId(1L);
        retraso.setIdPrestamo(3L);
        retraso.setIdDevolucion(7L);
        retraso.setDiasRetraso(5);

        when(service.calcularYGuardarDiasRetraso(3L, 7L))
                .thenReturn(Mono.just(5));

        when(service.guardarRetraso(any(Retraso.class)))
                .thenReturn(retraso);

        String json = """
                {
                    "idPrestamo": 3,
                    "idDevolucion": 7
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/retrasos")
                        .contentType("application/json")
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idPrestamo").value(3))
                .andExpect(jsonPath("$.diasRetraso").value(5));

        verify(service).calcularYGuardarDiasRetraso(3L, 7L);
        verify(service).guardarRetraso(any(Retraso.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "diasRetraso": 5
                }
                """;

        mockMvc.perform(post("/api/v1/retrasos")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarRetrasos() throws Exception {

        Retraso r1 = new Retraso();
        r1.setId(1L);
        r1.setDiasRetraso(5);

        when(service.listar())
                .thenReturn(List.of(r1));

        mockMvc.perform(get("/api/v1/retrasos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));

        verify(service).listar();
    }

    @Test
    void deberiaBorrarRetraso() throws Exception {

        mockMvc.perform(delete("/api/v1/retrasos/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarPorId(1L);
    }
}
