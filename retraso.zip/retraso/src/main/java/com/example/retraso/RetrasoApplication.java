package com.example.retraso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrasoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetrasoApplication.class, args);
	}

}
