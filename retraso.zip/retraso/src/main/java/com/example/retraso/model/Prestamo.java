package com.example.retraso.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
@Schema(description = "Entidad que representa los datos de un prestamo registrado en el sistema")
public class Prestamo {

    @Schema(
            description = "Identificador unico del prestamo",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @Schema(
            description = "Identiicador unico del libro que se esta prestando",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idLibro;
    @Schema(
            description = "Identiicador unico del usuario que pide el prestamo",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idUsuario;
    @Schema(
            description = "Fecha en la que se inicia el prestamo",
            example = "2026-07-23",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private LocalDate fechaInicioPrestamo;
    @Schema(
            description = "Fecha en la que se termina el prestamo",
            example = "2026-08-23",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private LocalDate fechaTerminoPrestamo;
    @Schema(
            description = "Estado en el que se encuentra el prestamo",
            example = "activo",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estadoPrestamo;

}
