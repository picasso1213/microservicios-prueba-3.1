package com.example.retraso.client;

import com.example.retraso.model.Prestamo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class PrestamoClient {

    private final WebClient webClient;

    public Mono<Prestamo> obtenerPrestamo(Long id) {
        return webClient.get()
                .uri("/api/v1/prestamos/id/" + id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Prestamo no encontrado"
                        ))
                )
                .bodyToMono(Prestamo.class);
    }

}
