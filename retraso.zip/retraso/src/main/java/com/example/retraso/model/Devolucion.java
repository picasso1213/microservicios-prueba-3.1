package com.example.retraso.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDate;

@Data
@Schema(description = "Entidad que representa los datos de una devolucion registrada en el sistema")
public class Devolucion {

    @Schema(
            description = "Identificador unico de la devolucion",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long idDevolucion;
    @Schema(
            description = "Identificador unico del prestamo asociado a la devolucion",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idPrestamo;
    @Schema(
            description = "Fecha en la que se efectuo la devolucion el libro prestado",
            example = "2026-09-12",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private LocalDate fechaDevolucion;
    @Schema(
            description = "Estado de conservacion en el que se encuentra el libro al momento de su devolucion",
            example = "dañado",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estadoLibro;

}
