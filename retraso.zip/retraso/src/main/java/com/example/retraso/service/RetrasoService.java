package com.example.retraso.service;

import com.example.retraso.client.DevolucionClient;
import com.example.retraso.client.PrestamoClient;
import com.example.retraso.model.Retraso;
import com.example.retraso.repository.RetrasoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class RetrasoService {

    private final PrestamoClient prestamoClient;
    private final DevolucionClient devolucionClient;
    @Autowired
    private RetrasoRepository repository;

    public Mono<Integer> calcularYGuardarDiasRetraso(Long idPrestamo, Long idDevolucion) {
        return prestamoClient.obtenerPrestamo(idPrestamo)
                .flatMap(prestamo -> devolucionClient.obtenerDevolucion(idDevolucion)
                        .map(devolucion -> {
                            long diasRetraso = ChronoUnit.DAYS.between(
                                    prestamo.getFechaTerminoPrestamo(),
                                    devolucion.getFechaDevolucion()
                            );
                            if (diasRetraso < 0) diasRetraso = 0;
                            return (int) diasRetraso;
                        })
                );
    }


    public List<Retraso> listar() {
        return repository.findAll();
    }

    public Optional<Retraso> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Retraso guardarRetraso(Retraso retraso) {
        return repository.save(retraso);
    }

    public Retraso actualizarRetraso(Retraso retraso) {
        return repository.save(retraso);
    }

}
