package com.example.retraso.repository;

import com.example.retraso.model.Retraso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RetrasoRepository extends JpaRepository<Retraso, Long> {
}
