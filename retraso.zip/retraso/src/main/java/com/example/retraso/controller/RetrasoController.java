package com.example.retraso.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.retraso.model.Retraso;
import com.example.retraso.service.RetrasoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/retrasos")
@RequiredArgsConstructor
public class RetrasoController {

    @Autowired
    private final RetrasoService service;

    @Operation(
            summary = "Crear retraso",
            description = "Registra un nuevo retraso en el sistema"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Retraso registrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public Mono<ResponseEntity<Retraso>> guardarRetraso(@Valid @RequestBody Retraso retraso) {
        return service.calcularYGuardarDiasRetraso(
                retraso.getIdPrestamo(),
                retraso.getIdDevolucion()
        ).map(dias -> {
            retraso.setDiasRetraso(dias);
            Retraso guardado = service.guardarRetraso(retraso);
            guardado.add(linkTo(methodOn(RetrasoController.class).listar()).withRel("mostrar todos los retrasos"));
            guardado.add(linkTo(methodOn(RetrasoController.class).buscarPorId(guardado.getId())).withSelfRel());
            guardado.add(linkTo(methodOn(RetrasoController.class).borrarPorId(guardado.getId())).withRel("borrar retraso"));
            guardado.add(linkTo(methodOn(RetrasoController.class).actualizarRetraso(guardado)).withRel("actualizar retraso"));
            return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
        });
    }

    @Operation(
            summary = "Listar retrasos",
            description = "Muestra una lista con todos los retrasos registrados en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Retrasos obtenidos correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Retraso> listar(){
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca un retraso dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Retraso encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Retraso no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Retraso> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(retraso -> {
                    retraso.add(linkTo(methodOn(RetrasoController.class).listar()).withRel("mostrar todos los retrasos"));
                    retraso.add(linkTo(methodOn(RetrasoController.class).borrarPorId(retraso.getId())).withRel("borrar retraso"));
                    retraso.add(linkTo(methodOn(RetrasoController.class).actualizarRetraso(retraso)).withRel("actualizar retraso"));
                    return ResponseEntity.ok(retraso);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Actualizar retraso",
            description = "Actualiza los datos de un retraso."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Retraso actualizado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Retraso no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public Retraso actualizarRetraso(@RequestBody Retraso retraso) {
        Retraso reActulizado = service.actualizarRetraso(retraso);
        reActulizado.add(linkTo(methodOn(RetrasoController.class).listar()).withRel("mostrar todos los retrasos"));
        reActulizado.add(linkTo(methodOn(RetrasoController.class).borrarPorId(reActulizado.getId())).withRel("borrar retraso"));
        reActulizado.add(linkTo(methodOn(RetrasoController.class).actualizarRetraso(reActulizado)).withRel("actualizar retraso"));
        return service.actualizarRetraso(retraso);
    }

    @Operation(
            summary = "Borrar retraso",
            description = "Se borra un retraso del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Retraso eliminado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Retraso no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try{
            service.borrarPorId(id);
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }

}
