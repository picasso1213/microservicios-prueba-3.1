package com.example.retraso.client;

import com.example.retraso.model.Devolucion;
import com.example.retraso.model.Prestamo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class DevolucionClient {

    private final WebClient devolucionWebClient;

    public Mono<Devolucion> obtenerDevolucion(Long id) {
        return devolucionWebClient.get()
                .uri("/api/v1/devoluciones/id/" + id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Devolucion no encontrada"
                        ))
                )
                .bodyToMono(Devolucion.class);
    }

}
