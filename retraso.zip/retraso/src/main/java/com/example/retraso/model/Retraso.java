package com.example.retraso.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un retraso registrado en el sistema")
public class Retraso extends RepresentationModel<Retraso> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificar unico del retraso",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long id;
    @NotNull
    @Schema(
            description = "Identificador unico del prestamo asociado al retraso",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idPrestamo;
    @NotNull
    @Schema(
            description = "Identificador unico de la devolucion asociada al prestamo",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idDevolucion;
    @Schema(
            description = "Calculo de dias entre el termino del prestamo y la devolucion de un libro",
            example = "15",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Integer diasRetraso;

}
