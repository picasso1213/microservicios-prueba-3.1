package com.example.retraso.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Value("${prestamo.service.url:http://localhost:9095}")
    private String prestamoServiceUrl;

    @Value("${devolucion.service.url:http://localhost:9096}")
    private String devolucionServiceUrl;

    @Bean
    public WebClient webClient(){
        return WebClient.builder()
                .baseUrl(prestamoServiceUrl) //Microservicio Prestamo
                .build();
    }

    @Bean
    public WebClient devolucionWebClient(){
        return WebClient.builder()
                .baseUrl(devolucionServiceUrl) //Microservicio Devolucion
                .build();
    }

}