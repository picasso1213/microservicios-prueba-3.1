CREATE TABLE retraso(
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_prestamo BIGINT,
    id_devolucion BIGINT,
    dias_retraso INT
);