package com.example.prestamo;

import com.example.prestamo.model.Prestamo;
import com.example.prestamo.repository.PrestamoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import com.example.prestamo.service.PrestamoService;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

import java.time.LocalDate;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class PrestamoServiceTest {

    @Mock
    private PrestamoRepository repository;

    @InjectMocks
    private PrestamoService service;

    @Test
    void deberiaRetornarPrestamoCuandoExiste() {

        Prestamo prestamo = new Prestamo();
        prestamo.setId(1L);
        prestamo.setIdLibro(10L);
        prestamo.setIdUsuario(20L);
        prestamo.setFechaInicioPrestamo(LocalDate.of(2026, 6, 1));
        prestamo.setFechaTerminoPrestamo(LocalDate.of(2026, 6, 15));
        prestamo.setEstadoPrestamo("ACTIVO");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(prestamo));

        Optional<Prestamo> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals("ACTIVO", resultado.get().getEstadoPrestamo());

        verify(repository).findById(1L);
    }
}
