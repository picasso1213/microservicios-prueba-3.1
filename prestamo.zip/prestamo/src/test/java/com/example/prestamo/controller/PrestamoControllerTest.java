package com.example.prestamo.controller;

import com.example.prestamo.client.LibroClient;
import com.example.prestamo.client.UsuarioClient;
import com.example.prestamo.model.Libro;
import com.example.prestamo.model.Prestamo;
import com.example.prestamo.model.Usuario;
import com.example.prestamo.service.PrestamoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.hateoas.MediaTypes;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PrestamoController.class)
@AutoConfigureMockMvc(addFilters = false)
class PrestamoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private PrestamoService service;

    @MockitoBean
    private LibroClient libroClient;

    @MockitoBean
    private UsuarioClient usuarioClient;

    @Test
    void deberiaRetornarPrestamoPorId() throws Exception {

        Prestamo prestamo = new Prestamo();
        prestamo.setId(1L);
        prestamo.setIdLibro(10L);
        prestamo.setIdUsuario(20L);
        prestamo.setFechaInicioPrestamo(LocalDate.of(2026, 6, 1));
        prestamo.setFechaTerminoPrestamo(LocalDate.of(2026, 6, 15));
        prestamo.setEstadoPrestamo("ACTIVO");

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(prestamo));

        mockMvc.perform(get("/api/v1/prestamos/id/1")
                        .accept(MediaTypes.HAL_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.idLibro").value(10))
                .andExpect(jsonPath("$.idUsuario").value(20))
                .andExpect(jsonPath("$.estadoPrestamo").value("ACTIVO"));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearPrestamo() throws Exception {

        Libro libro = new Libro();
        libro.setId(10L);
        libro.setTituloLibro("Cien años de soledad");

        Usuario usuario = new Usuario();
        usuario.setId(20L);
        usuario.setNombreUsuario("Juan");

        Prestamo prestamo = new Prestamo();
        //OJO añadir todos los campos NOTBLANK o NOTNULL
        prestamo.setId(1L);
        prestamo.setIdLibro(10L);
        prestamo.setIdUsuario(20L);
        prestamo.setFechaInicioPrestamo(LocalDate.of(2026, 6, 1));
        prestamo.setFechaTerminoPrestamo(LocalDate.of(2026, 6, 15));
        prestamo.setEstadoPrestamo("ACTIVO");

        when(libroClient.obtenerLibro(10L))
                .thenReturn(Mono.just(libro));

        when(usuarioClient.obtenerUsuario(20L))
                .thenReturn(Mono.just(usuario));

        when(service.guardarPrestamo(any(Prestamo.class)))
                .thenReturn(prestamo);

        //OJO añadir todos los campos NOTBLANK o NOTNULL
        String json = """
                {
                    "idLibro": 10,
                    "idUsuario": 20,
                    "fechaInicioPrestamo": "2026-06-01",
                    "fechaTerminoPrestamo": "2026-06-15",
                    "estadoPrestamo": "ACTIVO"
                }
                """;

        // El controller devuelve Mono<ResponseEntity<>>, por lo que MockMvc
        // procesa la petición en dos pasos: el dispatch inicial (async) y
        // luego el dispatch async para obtener el resultado final.
        MvcResult mvcResult = mockMvc.perform(post("/api/v1/prestamos")
                        .contentType("application/json")
                        .accept(MediaTypes.HAL_JSON)
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.idLibro").value(10))
                .andExpect(jsonPath("$.idUsuario").value(20))
                .andExpect(jsonPath("$.estadoPrestamo").value("ACTIVO"));



        verify(libroClient).obtenerLibro(10L);
        verify(usuarioClient).obtenerUsuario(20L);
        verify(service).guardarPrestamo(any(Prestamo.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "estadoPrestamo": "ACTIVO"
                }
                """;

        mockMvc.perform(post("/api/v1/prestamos")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }
}