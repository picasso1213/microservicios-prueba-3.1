package com.example.prestamo.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class Libro {

    private Long id;
    private String isbn;
    private String tituloLibro;
    private Long idAutor;
    private String genero;
    private String edadRecomendada;
    private int cantidadPaginas;
    private String editorial;
    private String annoPublicacion;
    private String estado;

}
