package com.example.prestamo.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.prestamo.client.LibroClient;
import com.example.prestamo.client.UsuarioClient;
import com.example.prestamo.model.Prestamo;
import com.example.prestamo.service.PrestamoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/prestamos")
@RequiredArgsConstructor
public class PrestamoController {

    private final LibroClient libroClient;
    private final UsuarioClient usuarioClient;
    @Autowired
    private final PrestamoService service;

    @Operation(
            summary = "Crear prestamo",
            description = "Registra un nuevo prestamo en el sistema"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Prestamo registrado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos invalidos"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @PostMapping
    public Mono<ResponseEntity<Prestamo>> guardarReserva(@Valid @RequestBody Prestamo prestamo) {
        return libroClient.obtenerLibro(prestamo.getIdLibro())
                .flatMap(libro -> usuarioClient.obtenerUsuario(prestamo.getIdUsuario())
                        .map(usuario -> {
                            Prestamo guardada = service.guardarPrestamo(prestamo);
                            guardada.add(linkTo(methodOn(PrestamoController.class).buscarPorId(guardada.getId())).withSelfRel());
                            guardada.add(linkTo(methodOn(PrestamoController.class).listar()).withRel("todos"));
                            guardada.add(linkTo(methodOn(PrestamoController.class).actualizarReserva(guardada)).withRel("update"));
                            guardada.add(linkTo(methodOn(PrestamoController.class).borrarPorId(guardada.getId())).withRel("delete"));
                            return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
                        })
                );
    }

    @Operation(
            summary = "Listar prestamos",
            description = "Muestra una lista con todos los prestamos registrados en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Prestamos obtenidos correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @GetMapping
    public List<Prestamo> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca un prestamo dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Prestamo encontrado correctamente"),
            @ApiResponse(responseCode = "404", description = "Prestamo no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Prestamo> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por ID usuario",
            description = "Muestra una lista de prestamos registrados con el ID de usuario buscado."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Prestamos encontrados correctamente"),
            @ApiResponse(responseCode = "204", description = "No se encontraron prestamos con el ID de usuario indicado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @GetMapping("/idUsuario/{idUsuario}")
    public ResponseEntity<List<Prestamo>> buscarPorIdUsuario(@PathVariable Long idUsuario) {
        List<Prestamo> prestamos = service.buscarPorIdUsuario(idUsuario);
        if (prestamos.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(prestamos);
        }
    }

    @Operation(
            summary = "Buscar por fecha inicio",
            description = "Muestra una lista de prestamos iniciados en la fecha buscada."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Prestamos encontrados correctamente"),
            @ApiResponse(responseCode = "204", description = "No se encontraron prestamos con la fecha indicada"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @GetMapping("/fechaInicio/{fechaInicio}")
    public ResponseEntity<List<Prestamo>> buscarPorFechaInicio(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio) {
        List<Prestamo> prestamos = service.buscarPorFechaInicio(fechaInicio);
        if (prestamos.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(prestamos);
        }
    }

    @Operation(
            summary = "Buscar por fecha termino",
            description = "Muestra una lista de prestamos que finalizan en la fecha buscada."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Prestamos encontrados correctamente"),
            @ApiResponse(responseCode = "204", description = "No se encontraron prestamos con la fecha indicada"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @GetMapping("/fechaTermino/{fechaTermino}")
    public ResponseEntity<List<Prestamo>> FechaTerminoPrestamo(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaTermino) {
        List<Prestamo> prestamos = service.buscarPorFechaTermino(fechaTermino);
        if (prestamos.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(prestamos);
        }
    }

    @Operation(
            summary = "Actualizar prestamo",
            description = "Actualiza los datos de un prestamo."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Prestamo actualizado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos invalidos"),
            @ApiResponse(responseCode = "404", description = "Prestamo no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @PutMapping
    public Prestamo actualizarReserva(@Valid @RequestBody Prestamo prestamo) {
        return service.actualizarPrestamo(prestamo);
    }

    @Operation(
            summary = "Borrar prestamo",
            description = "Se borra un prestamo del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Prestamo eliminado correctamente"),
            @ApiResponse(responseCode = "404", description = "Prestamo no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try {
            service.borrarPorId(id);
        } catch (NoSuchElementException ex) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}