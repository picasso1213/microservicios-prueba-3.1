package com.example.prestamo.service;

import com.example.prestamo.model.Prestamo;
import com.example.prestamo.repository.PrestamoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PrestamoService {

    @Autowired
    private PrestamoRepository repository;

    public List<Prestamo> listar() {
        return repository.findAll();
    }

    public Optional<Prestamo> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Prestamo guardarPrestamo(Prestamo reserva) {
        return repository.save(reserva);
    }

    public Prestamo actualizarPrestamo(Prestamo reserva) {
        return repository.save(reserva);
    }

    public List<Prestamo> buscarPorIdUsuario(Long id) {
        return repository.findByIdUsuario(id);
    }

    public List<Prestamo> buscarPorFechaInicio(LocalDate fechaInicio) {
        return repository.findByFechaInicioPrestamo(fechaInicio);
    }

    public List<Prestamo> buscarPorFechaTermino(LocalDate fechaTermino) {
        return repository.findByFechaTerminoPrestamo(fechaTermino);
    }


}
