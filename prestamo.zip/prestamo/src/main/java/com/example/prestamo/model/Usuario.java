package com.example.prestamo.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;

@Data
public class Usuario {

    private Long id;
    private String nombreUsuario;
    private String rutUsuario;
    private String telefonoUsuario;
    private String correoUsuario;
    private LocalDate fechaNacimiento;

}
