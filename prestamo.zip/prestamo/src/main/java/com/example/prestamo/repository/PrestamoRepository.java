package com.example.prestamo.repository;

import com.example.prestamo.model.Prestamo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface PrestamoRepository extends JpaRepository<Prestamo, Long> {

    List<Prestamo> findByIdUsuario(Long idUsuario);

    List<Prestamo> findByFechaInicioPrestamo(LocalDate fechaInicioPrestamo);

    List<Prestamo> findByFechaTerminoPrestamo(LocalDate fechaTerminoPrestamo);

}
