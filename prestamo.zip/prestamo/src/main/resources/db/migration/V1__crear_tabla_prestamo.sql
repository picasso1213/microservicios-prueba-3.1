CREATE TABLE prestamo (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_libro BIGINT,
    id_usuario BIGINT,
    fecha_inicio_prestamo DATE,
    fecha_termino_prestamo DATE,
    estado_prestamo VARCHAR(50)
)