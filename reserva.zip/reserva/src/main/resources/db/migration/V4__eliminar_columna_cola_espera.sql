ALTER TABLE reserva
    DROP COLUMN cola_espera;