CREATE TABLE reserva (
                         id_reserva BIGINT PRIMARY KEY AUTO_INCREMENT,
                         id_libro   BIGINT,
                         disponibilidad VARCHAR(50),
                         fecha_reserva  VARCHAR(50),
                         cola_espera    VARCHAR(500)
);