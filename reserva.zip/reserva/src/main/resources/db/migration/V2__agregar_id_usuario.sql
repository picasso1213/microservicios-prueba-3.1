ALTER TABLE reserva
    ADD COLUMN id_usuario BIGINT;