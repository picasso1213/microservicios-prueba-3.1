ALTER TABLE reserva
    DROP COLUMN disponibilidad;