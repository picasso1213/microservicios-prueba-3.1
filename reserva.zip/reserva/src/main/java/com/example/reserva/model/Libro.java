package com.example.reserva.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Entidad que representa los datos de un libro registrado en el sistema")
public class Libro {
    @Schema(
            description = "Identificador unico del libro",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long id;
    @Schema(
            description = "ISBN del libro",
            example = "978-607-8764-83-9",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String isbn;
    @Schema(
            description = "Nombre del libro",
            example = "Cien sonetos de amor",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String tituloLibro;
    @Schema(
            description = "Identificador unico del autor o autora del libro",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idAutor;
    @Schema(
            description = "Genero literario del libro",
            example = "Fantasia",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String genero;
    @Schema(
            description = "Rango etario recomendado para la lectura del libro",
            example = "15-25",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String edadRecomendada;
    @Schema(
            description = "Cantidad de paginas totales del libro",
            example = "302",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private int cantidadPaginas;
    @Schema(
            description = "Editorial responsable de la comercializacion del libro",
            example = "Editorial Losada",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String editorial;
    @Schema(
            description = "Año en el que fue publicado originalmente el libro",
            example = "1965",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String annoPublicacion;
    @Schema(
            description = "Estado de conservacion en el que se encuentra el libro",
            example = "Nuevo",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String estado;
}
