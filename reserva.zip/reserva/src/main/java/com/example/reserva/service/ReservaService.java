package com.example.reserva.service;

import com.example.reserva.model.Reserva;
import com.example.reserva.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository repository;

    public List<Reserva> listar() {
        return repository.findAll();
    }

    public Optional<Reserva> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Reserva guardarReserva(Reserva reserva) {
        return repository.save(reserva);
    }

    public Reserva actualizarReserva(Reserva reserva) {
        return repository.save(reserva);
    }

    public List<Reserva> buscarPorFecha(String fechaReserva){
        return repository.findByFechaReserva(fechaReserva);
    }

}

