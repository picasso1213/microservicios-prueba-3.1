package com.example.reserva.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Value("${libro.service.url:http://localhost:9092}")
    private String libroServiceUrl;

    @Value("${usuario.service.url:http://localhost:9090}")
    private String usuarioServiceUrl;

    @Bean
    public WebClient webClient() {
        return WebClient.builder()
                .baseUrl(libroServiceUrl)
                .build();
    }

    @Bean
    public WebClient usuarioWebClient() {
        return WebClient.builder()
                .baseUrl(usuarioServiceUrl)
                .build();
    }
}