package com.example.reserva.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.reserva.client.LibroClient;
import com.example.reserva.client.UsuarioClient;
import com.example.reserva.model.Reserva;
import com.example.reserva.service.ReservaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/reservas")
@RequiredArgsConstructor
public class ReservaController {

    private final LibroClient libroClient;
    private final UsuarioClient usuarioClient;
    private final ReservaService service;

    @Operation(
            summary = "Crear reserva",
            description = "Registrar una nueva reserva dentro del sistema"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Reserva registrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public Mono<ResponseEntity<Reserva>> guardarReserva(@Valid @RequestBody Reserva reserva) {
        return libroClient.obtenerLibro(reserva.getIdLibro())
                .flatMap(libro -> usuarioClient.obtenerUsuario(reserva.getIdUsuario())
                        .map(usuario -> {
                            Reserva guardada = service.guardarReserva(reserva);
                            guardada.add(linkTo(methodOn(ReservaController.class).listar()).withRel("mostrar todas las reservas"));
                            guardada.add(linkTo(methodOn(ReservaController.class).buscarPorId(guardada.getIdReserva())).withSelfRel());
                            guardada.add(linkTo(methodOn(ReservaController.class).borrarPorId(guardada.getIdReserva())).withRel("borrar reserva"));
                            guardada.add(linkTo(methodOn(ReservaController.class).actualizarReserva(guardada)).withRel("actulizar reserva"));
                            return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
                        })
                );
    }

    @Operation(
            summary = "Listar reservas",
            description = "Muestra una lista con todas las reservas registradas en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Reservas obtenidas correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Reserva> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca una reserva dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Reserva encontrada correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Reserva no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Reserva> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(reserva -> {
                    reserva.add(linkTo(methodOn(ReservaController.class).listar()).withRel("mostrar todas las reservas"));
                    reserva.add(linkTo(methodOn(ReservaController.class).borrarPorId(reserva.getIdReserva())).withRel("borrar reserva"));
                    reserva.add(linkTo(methodOn(ReservaController.class).actualizarReserva(reserva)).withRel("actulizar reserva"));
                    return ResponseEntity.ok(reserva);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por fecha",
            description = "Muestra una lista de reservas registradas en el dia buscado."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Reservas encontradas correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "No se encontraron reservas en la fecha indicada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/fechaReserva/{fechaReserva}")
    public ResponseEntity<List<Reserva>> buscarPorFecha(@PathVariable String fechaReserva) {
        List<Reserva> reservas = service.buscarPorFecha(fechaReserva);
        if(reservas.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            reservas.forEach( reserva -> {
                reserva.add(linkTo(methodOn(ReservaController.class).listar()).withRel("mostrar todas las reservas"));
                reserva.add(linkTo(methodOn(ReservaController.class).borrarPorId(reserva.getIdReserva())).withRel("borrar reserva"));
                reserva.add(linkTo(methodOn(ReservaController.class).actualizarReserva(reserva)).withRel("actulizar reserva"));
            });
            return ResponseEntity.ok(reservas);
        }
    }

    @Operation(
            summary = "Actualizar reserva",
            description = "Actualiza los datos de una reserva."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Reserva actualizada correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Reserva no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Reserva> actualizarReserva(@RequestBody Reserva reserva) {
        Reserva reActualizada = service.actualizarReserva(reserva);
        reActualizada.add(linkTo(methodOn(ReservaController.class).listar()).withRel("mostrar todas las reservas"));
        reActualizada.add(linkTo(methodOn(ReservaController.class).borrarPorId(reActualizada.getIdReserva())).withRel("borrar reserva"));
        reActualizada.add(linkTo(methodOn(ReservaController.class).actualizarReserva(reActualizada)).withRel("actulizar reserva"));
        return ResponseEntity.ok(reActualizada);
    }

    @Operation(
            summary = "Borrar reserva",
            description = "Se borra una reserva del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Reserva eliminada correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Reserva no encontrada"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try{
            service.borrarPorId(id);
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}