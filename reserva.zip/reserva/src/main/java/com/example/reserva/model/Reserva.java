package com.example.reserva.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa una reserva registrada en el sistema")
public class Reserva extends RepresentationModel<Reserva> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico de la reserva",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long idReserva;
    @NotNull
    @Schema(
            description = "Identificador unico del usuario que realiza la reserva",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idUsuario;
    @NotNull
    @Schema(
            description = "Identificador unico del libro que se esta reservando",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idLibro;
    @NotBlank
    @Schema(
            description = "Fecha en la que se realiza la reserva",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private String fechaReserva;

}

