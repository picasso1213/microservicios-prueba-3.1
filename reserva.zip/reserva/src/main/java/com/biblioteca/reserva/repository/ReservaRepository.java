package com.biblioteca.reserva.repository;

import com.biblioteca.reserva.model.Disponibilidad;
import com.biblioteca.reserva.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    // Buscar todas las reservas de un libro
    List<Reserva> findByIdLibro(Long idLibro);

    // Buscar reservas por disponibilidad
    List<Reserva> findByDisponibilidad(Disponibilidad disponibilidad);

    // Buscar reservas activas de un libro
    Optional<Reserva> findByIdLibroAndDisponibilidad(Long idLibro, Disponibilidad disponibilidad);

    // Buscar reservas por fecha
    List<Reserva> findByFechaReserva(LocalDate fechaReserva);

    // Buscar reservas en un rango de fechas
    List<Reserva> findByFechaReservaBetween(LocalDate inicio, LocalDate fin);

    // Verificar si un libro tiene reserva activa
    boolean existsByIdLibroAndDisponibilidad(Long idLibro, Disponibilidad disponibilidad);
}
