package com.biblioteca.reserva.exception;

// ══════════════════════════════════════════════════════════
//  Excepción personalizada
// ══════════════════════════════════════════════════════════
public class ReservaNotFoundException extends RuntimeException {

    public ReservaNotFoundException(String message) {
        super(message);
    }
}
