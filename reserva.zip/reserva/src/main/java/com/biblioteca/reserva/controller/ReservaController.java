package com.biblioteca.reserva.controller;

import com.biblioteca.reserva.dto.ReservaRequestDTO;
import com.biblioteca.reserva.dto.ReservaResponseDTO;
import com.biblioteca.reserva.model.Disponibilidad;
import com.biblioteca.reserva.service.ReservaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reservas")
@RequiredArgsConstructor
public class ReservaController {

    private final ReservaService reservaService;

    // ──────────────────────────────────────────────
    //  CRUD
    // ──────────────────────────────────────────────

    /** GET /api/v1/reservas  →  Listar todas las reservas */
    @GetMapping
    public ResponseEntity<List<ReservaResponseDTO>> listarTodas() {
        return ResponseEntity.ok(reservaService.obtenerTodas());
    }

    /** GET /api/v1/reservas/{id}  →  Obtener reserva por ID */
    @GetMapping("/{id}")
    public ResponseEntity<ReservaResponseDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(reservaService.obtenerPorId(id));
    }

    /** POST /api/v1/reservas  →  Crear nueva reserva */
    @PostMapping
    public ResponseEntity<ReservaResponseDTO> crearReserva(
            @Valid @RequestBody ReservaRequestDTO dto) {
        ReservaResponseDTO creada = reservaService.crearReserva(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }

    /** PUT /api/v1/reservas/{id}  →  Actualizar reserva */
    @PutMapping("/{id}")
    public ResponseEntity<ReservaResponseDTO> actualizarReserva(
            @PathVariable Long id,
            @Valid @RequestBody ReservaRequestDTO dto) {
        return ResponseEntity.ok(reservaService.actualizarReserva(id, dto));
    }

    /** DELETE /api/v1/reservas/{id}  →  Eliminar reserva */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarReserva(@PathVariable Long id) {
        reservaService.eliminarReserva(id);
        return ResponseEntity.noContent().build();
    }

    // ──────────────────────────────────────────────
    //  Lógica de negocio
    // ──────────────────────────────────────────────

    /**
     * POST /api/v1/reservas/{id}/cola/{idUsuario}
     * Agrega un usuario a la cola de espera de una reserva.
     */
    @PostMapping("/{id}/cola/{idUsuario}")
    public ResponseEntity<ReservaResponseDTO> agregarACola(
            @PathVariable Long id,
            @PathVariable Long idUsuario) {
        return ResponseEntity.ok(reservaService.agregarAColaEspera(id, idUsuario));
    }

    /**
     * PATCH /api/v1/reservas/{id}/liberar
     * Libera una reserva y asigna al siguiente en la cola.
     */
    @PatchMapping("/{id}/liberar")
    public ResponseEntity<ReservaResponseDTO> liberarReserva(@PathVariable Long id) {
        return ResponseEntity.ok(reservaService.liberarReserva(id));
    }

    // ──────────────────────────────────────────────
    //  Consultas
    // ──────────────────────────────────────────────

    /** GET /api/v1/reservas/libro/{idLibro}  →  Reservas de un libro */
    @GetMapping("/libro/{idLibro}")
    public ResponseEntity<List<ReservaResponseDTO>> obtenerPorLibro(@PathVariable Long idLibro) {
        return ResponseEntity.ok(reservaService.obtenerPorLibro(idLibro));
    }

    /**
     * GET /api/v1/reservas/disponibilidad/{estado}
     * Filtra reservas por estado de disponibilidad (DISPONIBLE, RESERVADO, PRESTADO, NO_DISPONIBLE)
     */
    @GetMapping("/disponibilidad/{estado}")
    public ResponseEntity<List<ReservaResponseDTO>> obtenerPorDisponibilidad(
            @PathVariable Disponibilidad estado) {
        return ResponseEntity.ok(reservaService.obtenerPorDisponibilidad(estado));
    }
}
