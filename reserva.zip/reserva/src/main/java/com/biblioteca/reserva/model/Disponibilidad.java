package com.biblioteca.reserva.model;

public enum Disponibilidad {
    DISPONIBLE,     // El libro está disponible para reserva
    RESERVADO,      // El libro ya fue reservado
    PRESTADO,       // El libro está actualmente prestado
    NO_DISPONIBLE   // El libro no está disponible (ej. en reparación)
}
