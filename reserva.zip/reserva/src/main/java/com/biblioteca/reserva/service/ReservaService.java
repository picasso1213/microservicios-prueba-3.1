package com.biblioteca.reserva.service;

import com.biblioteca.reserva.dto.ReservaRequestDTO;
import com.biblioteca.reserva.dto.ReservaResponseDTO;
import com.biblioteca.reserva.exception.ReservaNotFoundException;
import com.biblioteca.reserva.model.Disponibilidad;
import com.biblioteca.reserva.model.Reserva;
import com.biblioteca.reserva.repository.ReservaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReservaService {

    private final ReservaRepository reservaRepository;

    // ──────────────────────────────────────────────
    //  CRUD básico
    // ──────────────────────────────────────────────

    /** Obtener todas las reservas */
    public List<ReservaResponseDTO> obtenerTodas() {
        return reservaRepository.findAll()
                .stream()
                .map(ReservaResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    /** Obtener reserva por ID */
    public ReservaResponseDTO obtenerPorId(Long idReserva) {
        Reserva reserva = buscarPorId(idReserva);
        return ReservaResponseDTO.fromEntity(reserva);
    }

    /** Crear una nueva reserva */
    @Transactional
    public ReservaResponseDTO crearReserva(ReservaRequestDTO dto) {
        Reserva reserva = Reserva.builder()
                .idLibro(dto.getIdLibro())
                .disponibilidad(dto.getDisponibilidad() != null
                        ? dto.getDisponibilidad()
                        : Disponibilidad.RESERVADO)
                .fechaReserva(dto.getFechaReserva() != null
                        ? dto.getFechaReserva()
                        : LocalDate.now())
                .build();

        Reserva guardada = reservaRepository.save(reserva);
        log.info("Reserva creada: ID={}, Libro={}", guardada.getIdReserva(), guardada.getIdLibro());
        return ReservaResponseDTO.fromEntity(guardada);
    }

    /** Actualizar una reserva existente */
    @Transactional
    public ReservaResponseDTO actualizarReserva(Long idReserva, ReservaRequestDTO dto) {
        Reserva reserva = buscarPorId(idReserva);

        if (dto.getIdLibro() != null)         reserva.setIdLibro(dto.getIdLibro());
        if (dto.getDisponibilidad() != null)  reserva.setDisponibilidad(dto.getDisponibilidad());
        if (dto.getFechaReserva() != null)    reserva.setFechaReserva(dto.getFechaReserva());

        Reserva actualizada = reservaRepository.save(reserva);
        log.info("Reserva actualizada: ID={}", actualizada.getIdReserva());
        return ReservaResponseDTO.fromEntity(actualizada);
    }

    /** Eliminar una reserva */
    @Transactional
    public void eliminarReserva(Long idReserva) {
        Reserva reserva = buscarPorId(idReserva);
        reservaRepository.delete(reserva);
        log.info("Reserva eliminada: ID={}", idReserva);
    }

    // ──────────────────────────────────────────────
    //  Lógica de negocio - Cola de espera
    // ──────────────────────────────────────────────

    /**
     * Agrega un usuario a la cola de espera de una reserva.
     * Si el libro está disponible, lo reserva directamente.
     */
    @Transactional
    public ReservaResponseDTO agregarAColaEspera(Long idReserva, Long idUsuario) {
        Reserva reserva = buscarPorId(idReserva);

        if (reserva.getDisponibilidad() == Disponibilidad.DISPONIBLE) {
            reserva.setDisponibilidad(Disponibilidad.RESERVADO);
            log.info("Libro {} reservado directamente para usuario {}", reserva.getIdLibro(), idUsuario);
        } else {
            reserva.agregarAColaEspera(idUsuario);
            log.info("Usuario {} agregado a la cola de espera de la reserva {}. Posición: {}",
                    idUsuario, idReserva, reserva.getTamañoCola());
        }

        return ReservaResponseDTO.fromEntity(reservaRepository.save(reserva));
    }

    /**
     * Cancela/libera una reserva y asigna al siguiente en cola si hay usuarios esperando.
     */
    @Transactional
    public ReservaResponseDTO liberarReserva(Long idReserva) {
        Reserva reserva = buscarPorId(idReserva);

        Long siguiente = reserva.siguienteEnCola();
        if (siguiente != null) {
            reserva.setDisponibilidad(Disponibilidad.RESERVADO);
            log.info("Reserva {} asignada al siguiente usuario en cola: {}", idReserva, siguiente);
        } else {
            reserva.setDisponibilidad(Disponibilidad.DISPONIBLE);
            log.info("Reserva {} liberada. No hay usuarios en cola.", idReserva);
        }

        return ReservaResponseDTO.fromEntity(reservaRepository.save(reserva));
    }

    // ──────────────────────────────────────────────
    //  Consultas adicionales
    // ──────────────────────────────────────────────

    /** Obtener reservas por libro */
    public List<ReservaResponseDTO> obtenerPorLibro(Long idLibro) {
        return reservaRepository.findByIdLibro(idLibro)
                .stream()
                .map(ReservaResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    /** Obtener reservas por disponibilidad */
    public List<ReservaResponseDTO> obtenerPorDisponibilidad(Disponibilidad disponibilidad) {
        return reservaRepository.findByDisponibilidad(disponibilidad)
                .stream()
                .map(ReservaResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    // ──────────────────────────────────────────────
    //  Helper privado
    // ──────────────────────────────────────────────

    private Reserva buscarPorId(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new ReservaNotFoundException("Reserva no encontrada con ID: " + id));
    }
}
