package com.biblioteca.reserva.dto;

import com.biblioteca.reserva.model.Disponibilidad;
import com.biblioteca.reserva.model.Reserva;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Queue;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReservaResponseDTO {

    private Long idReserva;
    private Long idLibro;
    private Disponibilidad disponibilidad;
    private LocalDate fechaReserva;
    private List<Long> colaEspera;      // IDs de usuarios en espera
    private int tamañoCola;             // Cuántos usuarios esperan

    /**
     * Convierte una entidad Reserva en su DTO de respuesta.
     */
    public static ReservaResponseDTO fromEntity(Reserva reserva) {
        Queue<Long> cola = reserva.getColaEspera();
        return ReservaResponseDTO.builder()
                .idReserva(reserva.getIdReserva())
                .idLibro(reserva.getIdLibro())
                .disponibilidad(reserva.getDisponibilidad())
                .fechaReserva(reserva.getFechaReserva())
                .colaEspera(cola.stream().collect(Collectors.toList()))
                .tamañoCola(cola.size())
                .build();
    }
}
