package com.biblioteca.reserva.dto;

import com.biblioteca.reserva.model.Disponibilidad;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReservaRequestDTO {

    @NotNull(message = "El ID del libro es obligatorio")
    private Long idLibro;

    private Disponibilidad disponibilidad;

    @NotNull(message = "La fecha de reserva es obligatoria")
    private LocalDate fechaReserva;
}
