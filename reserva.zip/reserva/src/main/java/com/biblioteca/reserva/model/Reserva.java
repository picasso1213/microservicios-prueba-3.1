package com.biblioteca.reserva.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.Queue;

@Entity
@Table(name = "reservas")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reserva")
    private Long idReserva;

    @NotNull(message = "El ID del libro es obligatorio")
    @Column(name = "id_libro", nullable = false)
    private Long idLibro;

    @Enumerated(EnumType.STRING)
    @Column(name = "disponibilidad", nullable = false)
    @Builder.Default
    private Disponibilidad disponibilidad = Disponibilidad.DISPONIBLE;

    @NotNull(message = "La fecha de reserva es obligatoria")
    @Column(name = "fecha_reserva", nullable = false)
    private LocalDate fechaReserva;

    /**
     * Cola de espera: IDs de usuarios esperando este libro.
     * Se serializa como texto separado por comas en la BD.
     */
    @Column(name = "cola_espera", length = 1000)
    private String colaEsperaRaw;

    // ──────────────────────────────────────────────
    // Métodos de negocio para la cola de espera
    // ──────────────────────────────────────────────

    /**
     * Retorna la cola de espera como Queue<Long> (IDs de usuarios).
     */
    @Transient
    public Queue<Long> getColaEspera() {
        Queue<Long> cola = new LinkedList<>();
        if (colaEsperaRaw != null && !colaEsperaRaw.isBlank()) {
            for (String id : colaEsperaRaw.split(",")) {
                cola.offer(Long.parseLong(id.trim()));
            }
        }
        return cola;
    }

    /**
     * Agrega un usuario al final de la cola de espera.
     */
    public void agregarAColaEspera(Long idUsuario) {
        Queue<Long> cola = getColaEspera();
        if (!cola.contains(idUsuario)) {
            cola.offer(idUsuario);
        }
        serializarCola(cola);
    }

    /**
     * Saca al primer usuario de la cola de espera.
     *
     * @return ID del usuario o null si la cola está vacía
     */
    public Long siguienteEnCola() {
        Queue<Long> cola = getColaEspera();
        Long siguiente = cola.poll();
        serializarCola(cola);
        return siguiente;
    }

    /**
     * Cantidad de usuarios en espera.
     */
    @Transient
    public int getTamañoCola() {
        return getColaEspera().size();
    }

    private void serializarCola(Queue<Long> cola) {
        if (cola.isEmpty()) {
            this.colaEsperaRaw = null;
        } else {
            StringBuilder sb = new StringBuilder();
            for (Long id : cola) {
                if (!sb.isEmpty()) sb.append(",");
                sb.append(id);
            }
            this.colaEsperaRaw = sb.toString();
        }
    }
}
