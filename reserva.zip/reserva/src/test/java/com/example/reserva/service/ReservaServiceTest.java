package com.example.reserva.service;

import com.example.reserva.model.Reserva;
import com.example.reserva.repository.ReservaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ReservaServiceTest {

    @Mock
    private ReservaRepository repository;

    @InjectMocks
    private ReservaService service;

    @Test
    void deberiaRetornarReservaCuandoExiste() {

        Reserva reserva = new Reserva();
        reserva.setIdReserva(1L);
        reserva.setIdUsuario(5L);
        reserva.setIdLibro(10L);
        reserva.setFechaReserva("2026-06-21");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(reserva));

        Optional<Reserva> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(5L, resultado.get().getIdUsuario());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarReserva() {

        Reserva reserva = new Reserva();
        reserva.setIdUsuario(5L);
        reserva.setIdLibro(10L);
        reserva.setFechaReserva("2026-06-21");

        Mockito.when(repository.save(reserva))
                .thenReturn(reserva);

        Reserva guardada = service.guardarReserva(reserva);

        assertEquals(10L, guardada.getIdLibro());

        verify(repository).save(reserva);
    }
}
