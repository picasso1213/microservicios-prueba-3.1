package com.example.reserva.controller;

import com.example.reserva.client.LibroClient;
import com.example.reserva.client.UsuarioClient;
import com.example.reserva.model.Libro;
import com.example.reserva.model.Reserva;
import com.example.reserva.model.Usuario;
import com.example.reserva.service.ReservaService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReservaController.class)
@AutoConfigureMockMvc(addFilters = false)
class ReservaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ReservaService service;

    @MockitoBean
    private LibroClient libroClient;

    @MockitoBean
    private UsuarioClient usuarioClient;

    @Test
    void deberiaRetornarReservaPorId() throws Exception {

        Reserva reserva = new Reserva();
        reserva.setIdReserva(1L);
        reserva.setIdUsuario(5L);
        reserva.setIdLibro(10L);
        reserva.setFechaReserva("2026-06-21");

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(reserva));

        mockMvc.perform(get("/api/v1/reservas/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idReserva").value(1))
                .andExpect(jsonPath("$.idUsuario").value(5));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearReserva() throws Exception {

        Libro libro = new Libro();
        libro.setId(10L);

        Usuario usuario = new Usuario();
        usuario.setId(5L);

        Reserva reserva = new Reserva();
        reserva.setIdReserva(1L);
        reserva.setIdUsuario(5L);
        reserva.setIdLibro(10L);
        reserva.setFechaReserva("2026-06-21");

        when(libroClient.obtenerLibro(10L))
                .thenReturn(Mono.just(libro));

        when(usuarioClient.obtenerUsuario(5L))
                .thenReturn(Mono.just(usuario));

        when(service.guardarReserva(any(Reserva.class)))
                .thenReturn(reserva);

        String json = """
                {
                    "idUsuario": 5,
                    "idLibro": 10,
                    "fechaReserva": "2026-06-21"
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/reservas")
                        .contentType("application/json")
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idLibro").value(10))
                .andExpect(jsonPath("$.idUsuario").value(5));

        verify(libroClient).obtenerLibro(10L);
        verify(usuarioClient).obtenerUsuario(5L);
        verify(service).guardarReserva(any(Reserva.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "fechaReserva": "2026-06-21"
                }
                """;

        mockMvc.perform(post("/api/v1/reservas")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarReservas() throws Exception {

        Reserva r1 = new Reserva();
        r1.setIdReserva(1L);
        r1.setIdUsuario(5L);
        r1.setIdLibro(10L);
        r1.setFechaReserva("2026-06-21");

        when(service.listar())
                .thenReturn(List.of(r1));

        mockMvc.perform(get("/api/v1/reservas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].idReserva").value(1));

        verify(service).listar();
    }

    @Test
    void deberiaBuscarPorFecha() throws Exception {

        Reserva r1 = new Reserva();
        r1.setIdReserva(1L);
        r1.setFechaReserva("2026-06-21");

        when(service.buscarPorFecha("2026-06-21"))
                .thenReturn(List.of(r1));

        mockMvc.perform(get("/api/v1/reservas/fechaReserva/2026-06-21"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].fechaReserva").value("2026-06-21"));

        verify(service).buscarPorFecha("2026-06-21");
    }

    @Test
    void deberiaBorrarReserva() throws Exception {

        mockMvc.perform(delete("/api/v1/reservas/id/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarPorId(1L);
    }
}
