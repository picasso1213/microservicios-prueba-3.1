package com.example.Inventario.Service;

import com.example.Inventario.Model.Inventario;
import com.example.Inventario.Repository.InventarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class InventarioServiceTest {

    @Mock
    private InventarioRepository repository;

    @InjectMocks
    private InventarioService service;

    @Test
    void deberiaRetornarInventarioCuandoExiste() {

        Inventario inventario = new Inventario();
        inventario.setIdInventario(1L);
        inventario.setIdLibro(10L);
        inventario.setCantidadTotal(38);
        inventario.setCantidadDisponible(20);
        inventario.setCantidadReservada(15);
        inventario.setCantidadPrestada(18);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(inventario));

        Optional<Inventario> resultado = service.buscarPorId(1L);

        assertTrue(resultado.isPresent());
        assertEquals(20, resultado.get().getCantidadDisponible());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarInventario() {

        Inventario inventario = new Inventario();
        inventario.setIdLibro(20L);
        inventario.setCantidadTotal(10);
        inventario.setCantidadDisponible(10);
        inventario.setCantidadReservada(0);
        inventario.setCantidadPrestada(0);

        Mockito.when(repository.save(inventario))
                .thenReturn(inventario);

        Inventario guardado = service.save(inventario);

        assertEquals(10, guardado.getCantidadTotal());

        verify(repository).save(inventario);
    }
}
