package com.example.Inventario.Controller;

import com.example.Inventario.Client.LibroClient;
import com.example.Inventario.Model.Inventario;
import com.example.Inventario.Model.Libro;
import com.example.Inventario.Service.InventarioService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(InventarioController.class)
@AutoConfigureMockMvc(addFilters = false)
class InventarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private InventarioService service;

    @MockitoBean
    private LibroClient libroClient;

    @Test
    void deberiaRetornarInventarioPorId() throws Exception {

        Inventario inventario = new Inventario();
        inventario.setIdInventario(1L);
        inventario.setIdLibro(10L);
        inventario.setCantidadTotal(38);
        inventario.setCantidadDisponible(20);
        inventario.setCantidadReservada(15);
        inventario.setCantidadPrestada(18);

        when(service.buscarPorId(1L))
                .thenReturn(Optional.of(inventario));

        mockMvc.perform(get("/api/v1/inventario/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idInventario").value(1))
                .andExpect(jsonPath("$.cantidadDisponible").value(20));

        verify(service).buscarPorId(1L);
    }

    @Test
    void deberiaCrearInventario() throws Exception {

        Libro libro = new Libro();
        libro.setId(10L);
        libro.setTituloLibro("Cien sonetos de amor");

        Inventario inventario = new Inventario();
        inventario.setIdInventario(1L);
        inventario.setIdLibro(10L);
        inventario.setCantidadTotal(38);
        inventario.setCantidadDisponible(20);
        inventario.setCantidadReservada(15);
        inventario.setCantidadPrestada(18);

        when(libroClient.obtenerLibro(10L))
                .thenReturn(Mono.just(libro));

        when(service.save(any(Inventario.class)))
                .thenReturn(inventario);

        String json = """
                {
                    "idLibro": 10,
                    "cantidadTotal": 38,
                    "cantidadDisponible": 20,
                    "cantidadReservada": 15,
                    "cantidadPrestada": 18
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/api/v1/inventario")
                        .contentType("application/json")
                        .content(json))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idLibro").value(10))
                .andExpect(jsonPath("$.cantidadTotal").value(38));

        verify(libroClient).obtenerLibro(10L);
        verify(service).save(any(Inventario.class));
    }

    @Test
    void deberiaRetornar400CuandoFaltanCamposObligatorios() throws Exception {

        String json = """
                {
                    "cantidadTotal": 10
                }
                """;

        mockMvc.perform(post("/api/v1/inventario")
                        .contentType("application/json")
                        .content(json))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deberiaListarInventarios() throws Exception {

        Inventario i1 = new Inventario();
        i1.setIdInventario(1L);
        i1.setIdLibro(10L);

        when(service.listar())
                .thenReturn(List.of(i1));

        mockMvc.perform(get("/api/v1/inventario"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].idLibro").value(10));

        verify(service).listar();
    }

    @Test
    void deberiaBuscarPorIdLibro() throws Exception {

        Inventario i1 = new Inventario();
        i1.setIdInventario(1L);
        i1.setIdLibro(10L);

        when(service.buscarPorIdLibro(10L))
                .thenReturn(List.of(i1));

        mockMvc.perform(get("/api/v1/inventario/idLibro/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].idInventario").value(1));

        verify(service).buscarPorIdLibro(10L);
    }

    @Test
    void deberiaBorrarInventario() throws Exception {

        mockMvc.perform(delete("/api/v1/inventario/1"))
                .andExpect(status().isNoContent());

        verify(service).borrarInventarioPorId(1L);
    }
}
