ALTER TABLE inventario
    ADD COLUMN cantidad_reservada INT;