CREATE TABLE inventario(
    id_inventario BIGINT PRIMARY KEY AUTO_INCREMENT,
    id_libro BIGINT,
    cantidad_total INT
);