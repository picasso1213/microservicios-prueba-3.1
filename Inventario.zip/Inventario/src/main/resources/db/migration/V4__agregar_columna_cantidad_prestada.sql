ALTER TABLE inventario
    ADD COLUMN cantidad_prestada INT;