ALTER TABLE inventario
    ADD COLUMN cantidad_disponible INT;