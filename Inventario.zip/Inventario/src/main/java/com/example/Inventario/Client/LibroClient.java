package com.example.Inventario.Client;

import com.example.Inventario.Model.Libro;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class LibroClient {
    private final WebClient webClient;
    public Mono<Libro> obtenerLibro(Long id){
        return webClient.get()
                .uri("/api/v1/libros/id/" + id)
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, response ->
                        Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Libro no encontrado"
                        ))
                        )
                .bodyToMono(Libro.class);
    }
}
