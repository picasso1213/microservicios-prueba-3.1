package com.example.Inventario.Model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un espacio del inventario en el sistema")
public class Inventario extends RepresentationModel<Inventario> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador unico del inventario",
            example = "1",
            accessMode = Schema.AccessMode.READ_ONLY
    )
    private Long idInventario;
    @NotNull
    @Schema(
            description = "Identificador unico del libro",
            example = "1",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private Long idLibro;
    @NotNull
    @Schema(
            description = "Cantidad total de un libro que se encuentra en la biblioteca",
            example = "38",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private int cantidadTotal;
    @NotNull
    @Schema(
            description = "Cantidad total de libros que se encuentran diponibles para su prestamo",
            example = "20",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private int cantidadDisponible;
    @NotNull
    @Schema(
            description = "Cantidad de libros que se encuentran reservados, pero no en prestamo",
            example = "15",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private int cantidadReservada;
    @NotNull
    @Schema(
            description = "Cantidad de libros que se encuentran en prestamo",
            example = "18",
            requiredMode = Schema.RequiredMode.REQUIRED
    )
    private int cantidadPrestada;
}

