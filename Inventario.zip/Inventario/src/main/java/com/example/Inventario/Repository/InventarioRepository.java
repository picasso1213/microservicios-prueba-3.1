package com.example.Inventario.Repository;

import com.example.Inventario.Model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InventarioRepository extends JpaRepository<Inventario,Long> {

    List<Inventario> findByIdLibro (Long idLibro);

}
