package com.example.Inventario.Controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.Inventario.Client.LibroClient;
import com.example.Inventario.Model.Inventario;
import com.example.Inventario.Service.InventarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/inventario")
@RequiredArgsConstructor
public class InventarioController {

    private final LibroClient libroClient;
    @Autowired
    private final InventarioService service;

    @Operation(
            summary = "Crear inventario",
            description = "Registrar un nuevo espacio de inventario dentro del sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Inventario registrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos invalidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public Mono<ResponseEntity<Inventario>> crearInventario(@Valid @RequestBody Inventario inventario){
        return libroClient.obtenerLibro(inventario.getIdLibro())
                .map(libro -> {
                    Inventario guardado = service.save(inventario);
                    guardado.add(linkTo(methodOn(InventarioController.class).listar()).withRel("mostrar todos los inventarios"));
                    guardado.add(linkTo(methodOn(InventarioController.class).actualizarInventario(guardado)).withRel("actualizar inventario"));
                    guardado.add(linkTo(methodOn(InventarioController.class).borrarPorId(guardado.getIdInventario())).withRel("borrar inventario"));
                    guardado.add(linkTo(methodOn(InventarioController.class).buscarPorId(guardado.getIdInventario())).withSelfRel());
                    return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
                });
    }

    @Operation(
            summary = "Listar inventarios",
            description = "Muestra una lista con todos los espacios de inventario registrados en el sistema."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "inventarios obtenidos correctamente"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping
    public List<Inventario> listar(){
        return service.listar();
    }

    @Operation(
            summary = "Buscar por ID",
            description = "Busca un espacio de inventario dentro del sistema en base a su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Inventario encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Inventario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/id/{id}")
    public ResponseEntity<Inventario> buscarPorId(@PathVariable Long id) {
        return service.buscarPorId(id)
                .map(inventario -> {
                    inventario.add(linkTo(methodOn(InventarioController.class).listar()).withRel("mostrar todos los inventarios"));
                    inventario.add(linkTo(methodOn(InventarioController.class).actualizarInventario(inventario)).withRel("actualizar inventario"));
                    inventario.add(linkTo(methodOn(InventarioController.class).borrarPorId(inventario.getIdInventario())).withRel("borrar inventario"));
                    return ResponseEntity.ok(inventario);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar por ID libro",
            description = "Busca un espacio de inventario dentro del sistema en base al ID del libro que maneja."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Inventario encontrado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Inventario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @GetMapping("/idLibro/{idLibro}")
    public ResponseEntity<List<Inventario>> buscarPorIdLibro(@PathVariable Long idLibro) {
        List<Inventario> inventarios = service.buscarPorIdLibro(idLibro);
        if(inventarios.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            inventarios.forEach(inventario -> {
                inventario.add(linkTo(methodOn(InventarioController.class).listar()).withRel("mostrar todos los inventarios"));
                inventario.add(linkTo(methodOn(InventarioController.class).actualizarInventario(inventario)).withRel("actualizar inventario"));
                inventario.add(linkTo(methodOn(InventarioController.class).borrarPorId(inventario.getIdInventario())).withRel("borrar inventario"));
            });
            return ResponseEntity.ok(inventarios);
        }
    }

    @Operation(
            summary = "Actualizar inventario",
            description = "Actualiza los datos de un espacio de inventario."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Inventario actualizado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Inventario invalidos"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Inventario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PutMapping
    public ResponseEntity<Inventario> actualizarInventario(@Valid @RequestBody Inventario inventario) {
        Inventario inActualizado = service.actualizarInventario(inventario);
        inActualizado.add(linkTo(methodOn(InventarioController.class).buscarPorId(inActualizado.getIdInventario())).withSelfRel());
        inActualizado.add(linkTo(methodOn(InventarioController.class).listar()).withRel("mostrar todos los inventarios"));
        inActualizado.add(linkTo(methodOn(InventarioController.class).actualizarInventario(inActualizado)).withRel("actualizar inventario"));
        inActualizado.add(linkTo(methodOn(InventarioController.class).borrarPorId(inActualizado.getIdInventario())).withRel("borrar inventario"));
        return ResponseEntity.ok(inActualizado);
    }

    @Operation(
            summary = "Borrar inventario",
            description = "Se borra un espacio de inventario del sistema en base a su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Inventario eliminado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Inventario no encontrado"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @DeleteMapping("{id}")
    public ResponseEntity<Void> borrarPorId(@PathVariable Long id) {
        try{
            service.borrarInventarioPorId(id);
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }



}
