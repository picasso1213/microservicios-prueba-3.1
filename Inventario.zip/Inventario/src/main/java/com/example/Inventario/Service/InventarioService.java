package com.example.Inventario.Service;

import com.example.Inventario.Model.Inventario;
import com.example.Inventario.Repository.InventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InventarioService {
    @Autowired
    private InventarioRepository repository;

    public List<Inventario> listar(){
        return repository.findAll();
    }

    public Inventario save(Inventario inventario){
        return repository.save(inventario);
    }

    public Optional<Inventario> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public void borrarInventarioPorId(Long id) {
        buscarPorId(id).get();
        repository.deleteById(id);
    }

    public Inventario actualizarInventario(Inventario inventario) {
        return repository.save(inventario);
    }

    public List<Inventario> buscarPorIdLibro (Long idLibro) {
        return repository.findByIdLibro(idLibro);
    }

}
